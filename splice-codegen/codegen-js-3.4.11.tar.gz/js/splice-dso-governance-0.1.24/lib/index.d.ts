import * as Splice from './Splice';
export { Splice } ;
export declare const packageId = '4974c654485d4ecaa6b5caf8ef3c2679efa8195c4b50d4965a8fff1b72e8efa4';
