// Generated from Splice/DsoBootstrap.daml
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/no-use-before-define */
import * as jtv from '@mojotech/json-type-validation';
import * as damlTypes from '@daml/types';

import * as pkg7b784f7f03d3e035ea5d828ab64a476e7e0cbfffaec393619598f13e54d18013 from '@c7-digital/splice-codegen/splice-amulet-name-service-0.1.19';
import * as pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69 from '@c7-digital/splice-codegen/ghc-stdlib-DA-Internal-Template-1.0.0';
import * as pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a from '@c7-digital/splice-codegen/splice-amulet-0.1.18';
import * as pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946 from '@c7-digital/splice-codegen/daml-stdlib-DA-Time-Types-1.0.0';

import * as Splice_DSO_DecentralizedSynchronizer from '../../Splice/DSO/DecentralizedSynchronizer/module';
import * as Splice_DsoRules from '../../Splice/DsoRules/module';

export declare type DsoBootstrap_Bootstrap = {
};

export declare const DsoBootstrap_Bootstrap:
  damlTypes.Serializable<DsoBootstrap_Bootstrap> & {
  }
;


export declare type DsoBootstrap = {
  dso: damlTypes.Party;
  sv1Party: damlTypes.Party;
  sv1Name: string;
  sv1RewardWeight: damlTypes.Int;
  sv1ParticipantId: string;
  sv1SynchronizerNodes: damlTypes.Map<string, Splice_DSO_DecentralizedSynchronizer.SynchronizerNodeConfig>;
  round0Duration: pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946.DA.Time.Types.RelTime;
  amuletConfig: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletConfig.AmuletConfig<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletConfig.USD>;
  amuletPrice: damlTypes.Numeric;
  ansRulesConfig: pkg7b784f7f03d3e035ea5d828ab64a476e7e0cbfffaec393619598f13e54d18013.Splice.Ans.AnsRulesConfig;
  config: Splice_DsoRules.DsoRulesConfig;
  initialTrafficState: damlTypes.Map<string, Splice_DsoRules.TrafficState>;
  isDevNet: boolean;
  initialRound: damlTypes.Optional<damlTypes.Int>;
};

export declare interface DsoBootstrapInterface {
  Archive: damlTypes.Choice<DsoBootstrap, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoBootstrap, undefined>>;
  DsoBootstrap_Bootstrap: damlTypes.Choice<DsoBootstrap, DsoBootstrap_Bootstrap, DsoBootstrap_BootstrapResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoBootstrap, undefined>>;
}
export declare const DsoBootstrap:
  damlTypes.Template<DsoBootstrap, undefined, '#splice-dso-governance:Splice.DsoBootstrap:DsoBootstrap'> &
  damlTypes.ToInterface<DsoBootstrap, never> &
  DsoBootstrapInterface;

export declare namespace DsoBootstrap {
}



export declare type DsoBootstrap_BootstrapResult =
  | 'DsoBootstrap_BootstrapResult'
;

export declare const DsoBootstrap_BootstrapResult:
  damlTypes.Serializable<DsoBootstrap_BootstrapResult> & {
  }
& { readonly keys: DsoBootstrap_BootstrapResult[] } & { readonly [e in DsoBootstrap_BootstrapResult]: e }
;

