// Generated from Splice/DsoRules.daml
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/no-use-before-define */
import * as jtv from '@mojotech/json-type-validation';
import * as damlTypes from '@daml/types';

import * as pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8 from '@c7-digital/splice-codegen/splice-wallet-payments-0.1.18';
import * as pkg5aee9b21b8e9a4c4975b5f4c4198e6e6e8469df49e2010820e792f393db870f4 from '@c7-digital/splice-codegen/daml-prim-DA-Types-1.0.0';
import * as pkg7b784f7f03d3e035ea5d828ab64a476e7e0cbfffaec393619598f13e54d18013 from '@c7-digital/splice-codegen/splice-amulet-name-service-0.1.19';
import * as pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69 from '@c7-digital/splice-codegen/ghc-stdlib-DA-Internal-Template-1.0.0';
import * as pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a from '@c7-digital/splice-codegen/splice-amulet-0.1.18';
import * as pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946 from '@c7-digital/splice-codegen/daml-stdlib-DA-Time-Types-1.0.0';
import * as pkgc3bb0c5d04799b3f11bad7c3c102963e115cf53da3e4afcbcfd9f06ebd82b4ff from '@c7-digital/splice-codegen/daml-stdlib-DA-Set-Types-1.0.0';

import * as Splice_DSO_AmuletPrice from '../../Splice/DSO/AmuletPrice/module';
import * as Splice_DSO_DecentralizedSynchronizer from '../../Splice/DSO/DecentralizedSynchronizer/module';
import * as Splice_DSO_SvState from '../../Splice/DSO/SvState/module';
import * as Splice_SvOnboarding from '../../Splice/SvOnboarding/module';

export declare type BootstrapExternalPartyConfigStateInstruction = {
  dso: damlTypes.Party;
};

export declare interface BootstrapExternalPartyConfigStateInstructionInterface {
  Archive: damlTypes.Choice<BootstrapExternalPartyConfigStateInstruction, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<BootstrapExternalPartyConfigStateInstruction, undefined>>;
}
export declare const BootstrapExternalPartyConfigStateInstruction:
  damlTypes.Template<BootstrapExternalPartyConfigStateInstruction, undefined, '#splice-dso-governance:Splice.DsoRules:BootstrapExternalPartyConfigStateInstruction'> &
  damlTypes.ToInterface<BootstrapExternalPartyConfigStateInstruction, never> &
  BootstrapExternalPartyConfigStateInstructionInterface;

export declare namespace BootstrapExternalPartyConfigStateInstruction {
}



export declare type UnallocatedUnclaimedActivityRecord = {
  dso: damlTypes.Party;
  beneficiary: damlTypes.Party;
  amount: damlTypes.Numeric;
  reason: string;
  expiresAt: damlTypes.Time;
};

export declare interface UnallocatedUnclaimedActivityRecordInterface {
  Archive: damlTypes.Choice<UnallocatedUnclaimedActivityRecord, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<UnallocatedUnclaimedActivityRecord, undefined>>;
}
export declare const UnallocatedUnclaimedActivityRecord:
  damlTypes.Template<UnallocatedUnclaimedActivityRecord, undefined, '#splice-dso-governance:Splice.DsoRules:UnallocatedUnclaimedActivityRecord'> &
  damlTypes.ToInterface<UnallocatedUnclaimedActivityRecord, never> &
  UnallocatedUnclaimedActivityRecordInterface;

export declare namespace UnallocatedUnclaimedActivityRecord {
}



export declare type VotingState<a> = {
  rankings: damlTypes.Map<a, a[][]>;
  loosers: pkgc3bb0c5d04799b3f11bad7c3c102963e115cf53da3e4afcbcfd9f06ebd82b4ff.DA.Set.Types.Set<a>;
};

export declare const VotingState :
  (<a>(a: damlTypes.Serializable<a>) => damlTypes.Serializable<VotingState<a>>) & {
};


export declare type DsoRules_BootstrapExternalPartyConfigState = {
  amuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>;
  instructionCid: damlTypes.ContractId<BootstrapExternalPartyConfigStateInstruction>;
  openMiningRoundTriple: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.OpenMiningRoundTriple;
  sv: damlTypes.Party;
};

export declare const DsoRules_BootstrapExternalPartyConfigState:
  damlTypes.Serializable<DsoRules_BootstrapExternalPartyConfigState> & {
  }
;


export declare type DsoRules_CreateBootstrapExternalPartyConfigStateInstruction = {
};

export declare const DsoRules_CreateBootstrapExternalPartyConfigStateInstruction:
  damlTypes.Serializable<DsoRules_CreateBootstrapExternalPartyConfigStateInstruction> & {
  }
;


export declare type DsoRules_ExpireUnclaimedActivityRecord = {
  unclaimedActivityRecordCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.UnclaimedActivityRecord>;
  sv: damlTypes.Party;
};

export declare const DsoRules_ExpireUnclaimedActivityRecord:
  damlTypes.Serializable<DsoRules_ExpireUnclaimedActivityRecord> & {
  }
;


export declare type DsoRules_ExpireUnallocatedUnclaimedActivityRecord = {
  unallocatedUnclaimedActivityRecordCid: damlTypes.ContractId<UnallocatedUnclaimedActivityRecord>;
  sv: damlTypes.Party;
};

export declare const DsoRules_ExpireUnallocatedUnclaimedActivityRecord:
  damlTypes.Serializable<DsoRules_ExpireUnallocatedUnclaimedActivityRecord> & {
  }
;


export declare type DsoRules_AllocateUnallocatedUnclaimedActivityRecord = {
  unallocatedUnclaimedActivityRecordCid: damlTypes.ContractId<UnallocatedUnclaimedActivityRecord>;
  amuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>;
  unclaimedRewardsToBurnCids: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.UnclaimedReward>[];
  sv: damlTypes.Party;
};

export declare const DsoRules_AllocateUnallocatedUnclaimedActivityRecord:
  damlTypes.Serializable<DsoRules_AllocateUnallocatedUnclaimedActivityRecord> & {
  }
;


export declare type DsoRules_CreateUnallocatedUnclaimedActivityRecord = {
  beneficiary: damlTypes.Party;
  amount: damlTypes.Numeric;
  reason: string;
  expiresAt: damlTypes.Time;
};

export declare const DsoRules_CreateUnallocatedUnclaimedActivityRecord:
  damlTypes.Serializable<DsoRules_CreateUnallocatedUnclaimedActivityRecord> & {
  }
;


export declare type DsoRules_AmuletRules_ConvertFeaturedAppActivityMarkers = {
  amuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>;
  argument: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules_ConvertFeaturedAppActivityMarkers;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_AmuletRules_ConvertFeaturedAppActivityMarkers:
  damlTypes.Serializable<DsoRules_AmuletRules_ConvertFeaturedAppActivityMarkers> & {
  }
;


export declare type DsoRules_ExpireTransferPreapproval = {
  transferPreapprovalCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.TransferPreapproval>;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_ExpireTransferPreapproval:
  damlTypes.Serializable<DsoRules_ExpireTransferPreapproval> & {
  }
;


export declare type DsoRules_CreateTransferCommandCounter = {
  sender: damlTypes.Party;
};

export declare const DsoRules_CreateTransferCommandCounter:
  damlTypes.Serializable<DsoRules_CreateTransferCommandCounter> & {
  }
;


export declare type DsoRules_CreateExternalPartyAmuletRules = {
};

export declare const DsoRules_CreateExternalPartyAmuletRules:
  damlTypes.Serializable<DsoRules_CreateExternalPartyAmuletRules> & {
  }
;


export declare type DsoRules_PruneAmuletConfigSchedule = {
  amuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_PruneAmuletConfigSchedule:
  damlTypes.Serializable<DsoRules_PruneAmuletConfigSchedule> & {
  }
;


export declare type DsoRules_MergeSvRewardState = {
  svName: string;
  rewardStateCids: damlTypes.ContractId<Splice_DSO_SvState.SvRewardState>[];
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_MergeSvRewardState:
  damlTypes.Serializable<DsoRules_MergeSvRewardState> & {
  }
;


export declare type DsoRules_MergeMemberTrafficContracts = {
  amuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>;
  trafficCids: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.DecentralizedSynchronizer.MemberTraffic>[];
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_MergeMemberTrafficContracts:
  damlTypes.Serializable<DsoRules_MergeMemberTrafficContracts> & {
  }
;


export declare type DsoRules_ExpireStaleConfirmation = {
  staleConfirmationCid: damlTypes.ContractId<Confirmation>;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_ExpireStaleConfirmation:
  damlTypes.Serializable<DsoRules_ExpireStaleConfirmation> & {
  }
;


export declare type DsoRules_MiningRound_Close = {
  amuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>;
  issuingRoundCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Round.IssuingMiningRound>;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_MiningRound_Close:
  damlTypes.Serializable<DsoRules_MiningRound_Close> & {
  }
;


export declare type DsoRules_ExpireDevelopmentFundCoupon = {
  developmentFundCouponCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.DevelopmentFundCoupon>;
  sv: damlTypes.Party;
};

export declare const DsoRules_ExpireDevelopmentFundCoupon:
  damlTypes.Serializable<DsoRules_ExpireDevelopmentFundCoupon> & {
  }
;


export declare type DsoRules_MergeUnclaimedDevelopmentFundCoupons = {
  amuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>;
  choiceArg: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules_MergeUnclaimedDevelopmentFundCoupons;
  sv: damlTypes.Party;
};

export declare const DsoRules_MergeUnclaimedDevelopmentFundCoupons:
  damlTypes.Serializable<DsoRules_MergeUnclaimedDevelopmentFundCoupons> & {
  }
;


export declare type DsoRules_MergeUnclaimedRewards = {
  amuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>;
  unclaimedRewardCids: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.UnclaimedReward>[];
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_MergeUnclaimedRewards:
  damlTypes.Serializable<DsoRules_MergeUnclaimedRewards> & {
  }
;


export declare type DsoRules_ClaimExpiredRewards = {
  amuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>;
  choiceArg: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules_ClaimExpiredRewards;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_ClaimExpiredRewards:
  damlTypes.Serializable<DsoRules_ClaimExpiredRewards> & {
  }
;


export declare type DsoRules_ReceiveSvRewardCoupon = {
  sv: damlTypes.Party;
  openRoundCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Round.OpenMiningRound>;
  rewardStateCid: damlTypes.ContractId<Splice_DSO_SvState.SvRewardState>;
  beneficiaries: pkg5aee9b21b8e9a4c4975b5f4c4198e6e6e8469df49e2010820e792f393db870f4.DA.Types.Tuple2<damlTypes.Party, damlTypes.Int>[];
};

export declare const DsoRules_ReceiveSvRewardCoupon:
  damlTypes.Serializable<DsoRules_ReceiveSvRewardCoupon> & {
  }
;


export declare type DsoRules_TerminateSubscription = {
  ansEntryContextCid: damlTypes.ContractId<pkg7b784f7f03d3e035ea5d828ab64a476e7e0cbfffaec393619598f13e54d18013.Splice.Ans.AnsEntryContext>;
  terminatedSubscriptionCid: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.TerminatedSubscription>;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_TerminateSubscription:
  damlTypes.Serializable<DsoRules_TerminateSubscription> & {
  }
;


export declare type DsoRules_ExpireSubscription = {
  ansEntryContextCid: damlTypes.ContractId<pkg7b784f7f03d3e035ea5d828ab64a476e7e0cbfffaec393619598f13e54d18013.Splice.Ans.AnsEntryContext>;
  subscriptionIdleStateCid: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionIdleState>;
  choiceArg: pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionIdleState_ExpireSubscription;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_ExpireSubscription:
  damlTypes.Serializable<DsoRules_ExpireSubscription> & {
  }
;


export declare type DsoRules_ExpireAnsEntry = {
  ansEntryCid: damlTypes.ContractId<pkg7b784f7f03d3e035ea5d828ab64a476e7e0cbfffaec393619598f13e54d18013.Splice.Ans.AnsEntry>;
  choiceArg: pkg7b784f7f03d3e035ea5d828ab64a476e7e0cbfffaec393619598f13e54d18013.Splice.Ans.AnsEntry_Expire;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_ExpireAnsEntry:
  damlTypes.Serializable<DsoRules_ExpireAnsEntry> & {
  }
;


export declare type DsoRules_CollectEntryRenewalPayment = {
  ansEntryContextCid: damlTypes.ContractId<pkg7b784f7f03d3e035ea5d828ab64a476e7e0cbfffaec393619598f13e54d18013.Splice.Ans.AnsEntryContext>;
  choiceArg: pkg7b784f7f03d3e035ea5d828ab64a476e7e0cbfffaec393619598f13e54d18013.Splice.Ans.AnsEntryContext_CollectEntryRenewalPayment;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_CollectEntryRenewalPayment:
  damlTypes.Serializable<DsoRules_CollectEntryRenewalPayment> & {
  }
;


export declare type DsoRules_UpdateExternalPartyConfigStates = {
  amuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>;
  externalPartyConfigStateCid0: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.ExternalPartyConfigState.ExternalPartyConfigState>;
  externalPartyConfigStateCid1: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.ExternalPartyConfigState.ExternalPartyConfigState>;
  openMiningRoundTriple: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.OpenMiningRoundTriple;
  sv: damlTypes.Party;
};

export declare const DsoRules_UpdateExternalPartyConfigStates:
  damlTypes.Serializable<DsoRules_UpdateExternalPartyConfigStates> & {
  }
;


export declare type DsoRules_AdvanceOpenMiningRounds = {
  amuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>;
  roundToArchiveCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Round.OpenMiningRound>;
  middleRoundCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Round.OpenMiningRound>;
  latestRoundCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Round.OpenMiningRound>;
  amuletPriceVoteCids: damlTypes.ContractId<Splice_DSO_AmuletPrice.AmuletPriceVote>[];
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_AdvanceOpenMiningRounds:
  damlTypes.Serializable<DsoRules_AdvanceOpenMiningRounds> & {
  }
;


export declare type DsoRules_LockedAmulet_ExpireAmuletV2 = {
  cid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.LockedAmulet>;
  choiceArg: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.LockedAmulet_ExpireAmuletV2;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_LockedAmulet_ExpireAmuletV2:
  damlTypes.Serializable<DsoRules_LockedAmulet_ExpireAmuletV2> & {
  }
;


export declare type DsoRules_LockedAmulet_ExpireAmulet = {
  cid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.LockedAmulet>;
  choiceArg: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.LockedAmulet_ExpireAmulet;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_LockedAmulet_ExpireAmulet:
  damlTypes.Serializable<DsoRules_LockedAmulet_ExpireAmulet> & {
  }
;


export declare type DsoRules_Amulet_ExpireV2 = {
  cid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.Amulet>;
  choiceArg: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.Amulet_ExpireV2;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_Amulet_ExpireV2:
  damlTypes.Serializable<DsoRules_Amulet_ExpireV2> & {
  }
;


export declare type DsoRules_Amulet_Expire = {
  cid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.Amulet>;
  choiceArg: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.Amulet_Expire;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_Amulet_Expire:
  damlTypes.Serializable<DsoRules_Amulet_Expire> & {
  }
;


export declare type DsoRules_Amulet_ExpireTransferInstructions = {
  amuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>;
  transferInsts: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules_Amulet_ExpireTransferInstructions;
  sv: damlTypes.Party;
};

export declare const DsoRules_Amulet_ExpireTransferInstructions:
  damlTypes.Serializable<DsoRules_Amulet_ExpireTransferInstructions> & {
  }
;


export declare type DsoRules_ExpireAmuletAllocations = {
  extAmuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.ExternalPartyAmuletRules.ExternalPartyAmuletRules>;
  expireAllocations: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.ExternalPartyAmuletRules.ExternalPartyAmuletRules_ExpireAmuletAllocations;
  sv: damlTypes.Party;
};

export declare const DsoRules_ExpireAmuletAllocations:
  damlTypes.Serializable<DsoRules_ExpireAmuletAllocations> & {
  }
;


export declare type DsoRules_ExpireSvOnboardingConfirmed = {
  cid: damlTypes.ContractId<Splice_SvOnboarding.SvOnboardingConfirmed>;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_ExpireSvOnboardingConfirmed:
  damlTypes.Serializable<DsoRules_ExpireSvOnboardingConfirmed> & {
  }
;


export declare type DsoRules_ConfirmSvOnboarding = {
  newSvParty: damlTypes.Party;
  newSvName: string;
  newParticipantId: string;
  newSvRewardWeight: damlTypes.Int;
  reason: string;
};

export declare const DsoRules_ConfirmSvOnboarding:
  damlTypes.Serializable<DsoRules_ConfirmSvOnboarding> & {
  }
;


export declare type DsoRules_ArchiveSvOnboardingRequest = {
  svOnboardingRequestCid: damlTypes.ContractId<Splice_SvOnboarding.SvOnboardingRequest>;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_ArchiveSvOnboardingRequest:
  damlTypes.Serializable<DsoRules_ArchiveSvOnboardingRequest> & {
  }
;


export declare type DsoRules_ExpireSvOnboardingRequest = {
  cid: damlTypes.ContractId<Splice_SvOnboarding.SvOnboardingRequest>;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_ExpireSvOnboardingRequest:
  damlTypes.Serializable<DsoRules_ExpireSvOnboardingRequest> & {
  }
;


export declare type DsoRules_StartSvOnboarding = {
  candidateName: string;
  candidateParty: damlTypes.Party;
  candidateParticipantId: string;
  token: string;
  sponsor: damlTypes.Party;
};

export declare const DsoRules_StartSvOnboarding:
  damlTypes.Serializable<DsoRules_StartSvOnboarding> & {
  }
;


export declare type DsoRules_MergeValidatorLicense = {
  validatorLicenseCids: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.ValidatorLicense.ValidatorLicense>[];
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_MergeValidatorLicense:
  damlTypes.Serializable<DsoRules_MergeValidatorLicense> & {
  }
;


export declare type DsoRules_OnboardValidator = {
  sponsor: damlTypes.Party;
  validator: damlTypes.Party;
  version: damlTypes.Optional<string>;
  contactPoint: damlTypes.Optional<string>;
};

export declare const DsoRules_OnboardValidator:
  damlTypes.Serializable<DsoRules_OnboardValidator> & {
  }
;


export declare type DsoRules_RevokeFeaturedAppRight = {
  rightCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.FeaturedAppRight>;
};

export declare const DsoRules_RevokeFeaturedAppRight:
  damlTypes.Serializable<DsoRules_RevokeFeaturedAppRight> & {
  }
;


export declare type DsoRules_GrantFeaturedAppRight = {
  provider: damlTypes.Party;
};

export declare const DsoRules_GrantFeaturedAppRight:
  damlTypes.Serializable<DsoRules_GrantFeaturedAppRight> & {
  }
;


export declare type DsoRules_UpdateSvRewardWeight = {
  svParty: damlTypes.Party;
  newRewardWeight: damlTypes.Int;
};

export declare const DsoRules_UpdateSvRewardWeight:
  damlTypes.Serializable<DsoRules_UpdateSvRewardWeight> & {
  }
;


export declare type DsoRules_SetConfig = {
  newConfig: DsoRulesConfig;
  baseConfig: damlTypes.Optional<DsoRulesConfig>;
};

export declare const DsoRules_SetConfig:
  damlTypes.Serializable<DsoRules_SetConfig> & {
  }
;


export declare type DsoRules_GarbageCollectAmuletPriceVotes = {
  nonSvVoteCids: damlTypes.ContractId<Splice_DSO_AmuletPrice.AmuletPriceVote>[];
  duplicateVoteCids: damlTypes.ContractId<Splice_DSO_AmuletPrice.AmuletPriceVote>[][];
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_GarbageCollectAmuletPriceVotes:
  damlTypes.Serializable<DsoRules_GarbageCollectAmuletPriceVotes> & {
  }
;


export declare type DsoRules_UpdateAmuletPriceVote = {
  sv: damlTypes.Party;
  voteCid: damlTypes.ContractId<Splice_DSO_AmuletPrice.AmuletPriceVote>;
  amuletPrice: damlTypes.Numeric;
};

export declare const DsoRules_UpdateAmuletPriceVote:
  damlTypes.Serializable<DsoRules_UpdateAmuletPriceVote> & {
  }
;


export declare type DsoRules_CloseVoteRequest = {
  requestCid: damlTypes.ContractId<VoteRequest>;
  amuletRulesCid: damlTypes.Optional<damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>>;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_CloseVoteRequest:
  damlTypes.Serializable<DsoRules_CloseVoteRequest> & {
  }
;


export declare type DsoRules_CastVote = {
  requestCid: damlTypes.ContractId<VoteRequest>;
  vote: Vote;
};

export declare const DsoRules_CastVote:
  damlTypes.Serializable<DsoRules_CastVote> & {
  }
;


export declare type DsoRules_RequestVote = {
  requester: damlTypes.Party;
  action: ActionRequiringConfirmation;
  reason: Reason;
  voteRequestTimeout: damlTypes.Optional<pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946.DA.Time.Types.RelTime>;
  targetEffectiveAt: damlTypes.Optional<damlTypes.Time>;
};

export declare const DsoRules_RequestVote:
  damlTypes.Serializable<DsoRules_RequestVote> & {
  }
;


export declare type DsoRules_ExecuteConfirmedAction = {
  action: ActionRequiringConfirmation;
  amuletRulesCid: damlTypes.Optional<damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>>;
  confirmationCids: damlTypes.ContractId<Confirmation>[];
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_ExecuteConfirmedAction:
  damlTypes.Serializable<DsoRules_ExecuteConfirmedAction> & {
  }
;


export declare type DsoRules_ConfirmAction = {
  confirmer: damlTypes.Party;
  action: ActionRequiringConfirmation;
};

export declare const DsoRules_ConfirmAction:
  damlTypes.Serializable<DsoRules_ConfirmAction> & {
  }
;


export declare type DsoRules_ArchiveOutdatedElectionRequest = {
  requestCid: damlTypes.ContractId<ElectionRequest>;
  sv: damlTypes.Optional<damlTypes.Party>;
};

export declare const DsoRules_ArchiveOutdatedElectionRequest:
  damlTypes.Serializable<DsoRules_ArchiveOutdatedElectionRequest> & {
  }
;


export declare type DsoRules_ElectDsoDelegate = {
  actor: damlTypes.Party;
  requestCids: damlTypes.ContractId<ElectionRequest>[];
};

export declare const DsoRules_ElectDsoDelegate:
  damlTypes.Serializable<DsoRules_ElectDsoDelegate> & {
  }
;


export declare type DsoRules_RequestElection = {
  requester: damlTypes.Party;
  reason: ElectionRequestReason;
  ranking: damlTypes.Party[];
};

export declare const DsoRules_RequestElection:
  damlTypes.Serializable<DsoRules_RequestElection> & {
  }
;


export declare type DsoRules_SetSynchronizerNodeConfig = {
  sv: damlTypes.Party;
  synchronizerId: string;
  newNodeConfig: Splice_DSO_DecentralizedSynchronizer.SynchronizerNodeConfig;
  nodeStateCid: damlTypes.ContractId<Splice_DSO_SvState.SvNodeState>;
};

export declare const DsoRules_SetSynchronizerNodeConfig:
  damlTypes.Serializable<DsoRules_SetSynchronizerNodeConfig> & {
  }
;


export declare type DsoRules_AddConfirmedSv = {
  sv: damlTypes.Party;
  svOnboardingConfirmedCid: damlTypes.ContractId<Splice_SvOnboarding.SvOnboardingConfirmed>;
  earliestRoundCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Round.OpenMiningRound>;
  middleRoundCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Round.OpenMiningRound>;
  latestRoundCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Round.OpenMiningRound>;
  amuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>;
};

export declare const DsoRules_AddConfirmedSv:
  damlTypes.Serializable<DsoRules_AddConfirmedSv> & {
  }
;


export declare type DsoRules_SubmitStatusReport = {
  sv: damlTypes.Party;
  previousReportCid: damlTypes.ContractId<Splice_DSO_SvState.SvStatusReport>;
  status: Splice_DSO_SvState.SvStatus;
};

export declare const DsoRules_SubmitStatusReport:
  damlTypes.Serializable<DsoRules_SubmitStatusReport> & {
  }
;


export declare type DsoRules_OffboardSv = {
  sv: damlTypes.Party;
};

export declare const DsoRules_OffboardSv:
  damlTypes.Serializable<DsoRules_OffboardSv> & {
  }
;


export declare type DsoRules_AddSv = {
  newSvParty: damlTypes.Party;
  newSvName: string;
  newSvRewardWeight: damlTypes.Int;
  newSvParticipantId: string;
  joinedAsOfRound: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Types.Round;
};

export declare const DsoRules_AddSv:
  damlTypes.Serializable<DsoRules_AddSv> & {
  }
;


export declare type DsoRules = {
  dso: damlTypes.Party;
  epoch: damlTypes.Int;
  svs: damlTypes.Map<damlTypes.Party, SvInfo>;
  offboardedSvs: damlTypes.Map<damlTypes.Party, OffboardedSvInfo>;
  dsoDelegate: damlTypes.Party;
  config: DsoRulesConfig;
  initialTrafficState: damlTypes.Map<string, TrafficState>;
  isDevNet: boolean;
};

export declare interface DsoRulesInterface {
  DsoRules_AddSv: damlTypes.Choice<DsoRules, DsoRules_AddSv, DsoRules_AddSvResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_UpdateAmuletPriceVote: damlTypes.Choice<DsoRules, DsoRules_UpdateAmuletPriceVote, DsoRules_UpdateAmuletPriceVoteResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_CastVote: damlTypes.Choice<DsoRules, DsoRules_CastVote, DsoRules_CastVoteResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  Archive: damlTypes.Choice<DsoRules, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_OffboardSv: damlTypes.Choice<DsoRules, DsoRules_OffboardSv, DsoRules_OffboardSvResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_SubmitStatusReport: damlTypes.Choice<DsoRules, DsoRules_SubmitStatusReport, DsoRules_SubmitStatusReportResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_AddConfirmedSv: damlTypes.Choice<DsoRules, DsoRules_AddConfirmedSv, DsoRules_AddConfirmedSvResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_SetSynchronizerNodeConfig: damlTypes.Choice<DsoRules, DsoRules_SetSynchronizerNodeConfig, DsoRules_SetSynchronizerNodeConfigResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ConfirmAction: damlTypes.Choice<DsoRules, DsoRules_ConfirmAction, DsoRules_ConfirmActionResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ExecuteConfirmedAction: damlTypes.Choice<DsoRules, DsoRules_ExecuteConfirmedAction, DsoRules_ExecuteConfirmedActionResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_RequestVote: damlTypes.Choice<DsoRules, DsoRules_RequestVote, DsoRules_RequestVoteResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_CloseVoteRequest: damlTypes.Choice<DsoRules, DsoRules_CloseVoteRequest, DsoRules_CloseVoteRequestResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_GarbageCollectAmuletPriceVotes: damlTypes.Choice<DsoRules, DsoRules_GarbageCollectAmuletPriceVotes, DsoRules_GarbageCollectAmuletPriceVotesResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_SetConfig: damlTypes.Choice<DsoRules, DsoRules_SetConfig, DsoRules_SetConfigResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_UpdateSvRewardWeight: damlTypes.Choice<DsoRules, DsoRules_UpdateSvRewardWeight, DsoRules_UpdateSvRewardWeightResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_GrantFeaturedAppRight: damlTypes.Choice<DsoRules, DsoRules_GrantFeaturedAppRight, DsoRules_GrantFeaturedAppRightResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_RevokeFeaturedAppRight: damlTypes.Choice<DsoRules, DsoRules_RevokeFeaturedAppRight, DsoRules_RevokeFeaturedAppRightResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_OnboardValidator: damlTypes.Choice<DsoRules, DsoRules_OnboardValidator, DsoRules_OnboardValidatorResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_MergeValidatorLicense: damlTypes.Choice<DsoRules, DsoRules_MergeValidatorLicense, DsoRules_MergeValidatorLicenseResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_StartSvOnboarding: damlTypes.Choice<DsoRules, DsoRules_StartSvOnboarding, DsoRules_StartSvOnboardingResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ExpireSvOnboardingRequest: damlTypes.Choice<DsoRules, DsoRules_ExpireSvOnboardingRequest, DsoRules_ExpireSvOnboardingRequestResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ArchiveSvOnboardingRequest: damlTypes.Choice<DsoRules, DsoRules_ArchiveSvOnboardingRequest, DsoRules_ArchiveSvOnboardingRequestResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ConfirmSvOnboarding: damlTypes.Choice<DsoRules, DsoRules_ConfirmSvOnboarding, DsoRules_ConfirmSvOnboardingResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ExpireSvOnboardingConfirmed: damlTypes.Choice<DsoRules, DsoRules_ExpireSvOnboardingConfirmed, DsoRules_ExpireSvOnboardingConfirmedResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ExpireAmuletAllocations: damlTypes.Choice<DsoRules, DsoRules_ExpireAmuletAllocations, DsoRules_ExpireAmuletAllocationsResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_Amulet_ExpireTransferInstructions: damlTypes.Choice<DsoRules, DsoRules_Amulet_ExpireTransferInstructions, DsoRules_Amulet_ExpireTransferInstructionsResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_Amulet_ExpireV2: damlTypes.Choice<DsoRules, DsoRules_Amulet_ExpireV2, DsoRules_Amulet_ExpireV2Result, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_LockedAmulet_ExpireAmulet: damlTypes.Choice<DsoRules, DsoRules_LockedAmulet_ExpireAmulet, DsoRules_LockedAmulet_ExpireAmuletResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_LockedAmulet_ExpireAmuletV2: damlTypes.Choice<DsoRules, DsoRules_LockedAmulet_ExpireAmuletV2, DsoRules_LockedAmulet_ExpireAmuletV2Result, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_AdvanceOpenMiningRounds: damlTypes.Choice<DsoRules, DsoRules_AdvanceOpenMiningRounds, DsoRules_AdvanceOpenMiningRoundsResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_UpdateExternalPartyConfigStates: damlTypes.Choice<DsoRules, DsoRules_UpdateExternalPartyConfigStates, DsoRules_UpdateExternalPartyConfigStatesResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_CollectEntryRenewalPayment: damlTypes.Choice<DsoRules, DsoRules_CollectEntryRenewalPayment, DsoRules_CollectEntryRenewalPaymentResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ExpireAnsEntry: damlTypes.Choice<DsoRules, DsoRules_ExpireAnsEntry, DsoRules_ExpireAnsEntryResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ExpireSubscription: damlTypes.Choice<DsoRules, DsoRules_ExpireSubscription, DsoRules_ExpireSubscriptionResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_TerminateSubscription: damlTypes.Choice<DsoRules, DsoRules_TerminateSubscription, DsoRules_TerminateSubscriptionResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ReceiveSvRewardCoupon: damlTypes.Choice<DsoRules, DsoRules_ReceiveSvRewardCoupon, DsoRules_ReceiveSvRewardCouponResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ClaimExpiredRewards: damlTypes.Choice<DsoRules, DsoRules_ClaimExpiredRewards, DsoRules_ClaimExpiredRewardsResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_MergeUnclaimedRewards: damlTypes.Choice<DsoRules, DsoRules_MergeUnclaimedRewards, DsoRules_MergeUnclaimedRewardsResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_MergeUnclaimedDevelopmentFundCoupons: damlTypes.Choice<DsoRules, DsoRules_MergeUnclaimedDevelopmentFundCoupons, DsoRules_MergeUnclaimedDevelopmentFundCouponsResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ExpireDevelopmentFundCoupon: damlTypes.Choice<DsoRules, DsoRules_ExpireDevelopmentFundCoupon, DsoRules_ExpireDevelopmentFundCouponResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_MiningRound_Close: damlTypes.Choice<DsoRules, DsoRules_MiningRound_Close, DsoRules_MiningRound_CloseResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ExpireStaleConfirmation: damlTypes.Choice<DsoRules, DsoRules_ExpireStaleConfirmation, DsoRules_ExpireStaleConfirmationResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_MergeMemberTrafficContracts: damlTypes.Choice<DsoRules, DsoRules_MergeMemberTrafficContracts, DsoRules_MergeMemberTrafficContractsResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_MergeSvRewardState: damlTypes.Choice<DsoRules, DsoRules_MergeSvRewardState, DsoRules_MergeSvRewardStateResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_CreateExternalPartyAmuletRules: damlTypes.Choice<DsoRules, DsoRules_CreateExternalPartyAmuletRules, DsoRules_CreateExternalPartyAmuletRulesResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_CreateTransferCommandCounter: damlTypes.Choice<DsoRules, DsoRules_CreateTransferCommandCounter, DsoRules_CreateTransferCommandCounterResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ExpireTransferPreapproval: damlTypes.Choice<DsoRules, DsoRules_ExpireTransferPreapproval, DsoRules_ExpireTransferPreapprovalResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_AmuletRules_ConvertFeaturedAppActivityMarkers: damlTypes.Choice<DsoRules, DsoRules_AmuletRules_ConvertFeaturedAppActivityMarkers, DsoRules_AmuletRules_ConvertFeaturedAppActivityMarkersResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_CreateUnallocatedUnclaimedActivityRecord: damlTypes.Choice<DsoRules, DsoRules_CreateUnallocatedUnclaimedActivityRecord, DsoRules_CreateUnallocatedUnclaimedActivityRecordResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_AllocateUnallocatedUnclaimedActivityRecord: damlTypes.Choice<DsoRules, DsoRules_AllocateUnallocatedUnclaimedActivityRecord, DsoRules_AllocateUnallocatedUnclaimedActivityRecordResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ExpireUnallocatedUnclaimedActivityRecord: damlTypes.Choice<DsoRules, DsoRules_ExpireUnallocatedUnclaimedActivityRecord, DsoRules_ExpireUnallocatedUnclaimedActivityRecordResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ExpireUnclaimedActivityRecord: damlTypes.Choice<DsoRules, DsoRules_ExpireUnclaimedActivityRecord, DsoRules_ExpireUnclaimedActivityRecordResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_CreateBootstrapExternalPartyConfigStateInstruction: damlTypes.Choice<DsoRules, DsoRules_CreateBootstrapExternalPartyConfigStateInstruction, DsoRules_CreateBootstrapExternalPartyConfigStateInstructionResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_BootstrapExternalPartyConfigState: damlTypes.Choice<DsoRules, DsoRules_BootstrapExternalPartyConfigState, DsoRules_BootstrapExternalPartyConfigStateResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_PruneAmuletConfigSchedule: damlTypes.Choice<DsoRules, DsoRules_PruneAmuletConfigSchedule, DsoRules_PruneAmuletConfigScheduleResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_RequestElection: damlTypes.Choice<DsoRules, DsoRules_RequestElection, DsoRules_RequestElectionResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ElectDsoDelegate: damlTypes.Choice<DsoRules, DsoRules_ElectDsoDelegate, DsoRules_ElectDsoDelegateResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_ArchiveOutdatedElectionRequest: damlTypes.Choice<DsoRules, DsoRules_ArchiveOutdatedElectionRequest, DsoRules_ArchiveOutdatedElectionRequestResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
  DsoRules_Amulet_Expire: damlTypes.Choice<DsoRules, DsoRules_Amulet_Expire, DsoRules_Amulet_ExpireResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoRules, undefined>>;
}
export declare const DsoRules:
  damlTypes.Template<DsoRules, undefined, '#splice-dso-governance:Splice.DsoRules:DsoRules'> &
  damlTypes.ToInterface<DsoRules, never> &
  DsoRulesInterface;

export declare namespace DsoRules {
}



export declare type TrafficState = {
  consumedTraffic: damlTypes.Int;
};

export declare const TrafficState:
  damlTypes.Serializable<TrafficState> & {
  }
;


export declare type LogicalSynchronizerUpgradeSchedule = {
  topologyFreezeTime: damlTypes.Time;
  upgradeTime: damlTypes.Time;
  newPhysicalSynchronizerSerial: damlTypes.Int;
  newPhysicalSynchronizerProtocolVersion: string;
};

export declare const LogicalSynchronizerUpgradeSchedule:
  damlTypes.Serializable<LogicalSynchronizerUpgradeSchedule> & {
  }
;


export declare type SynchronizerUpgradeSchedule = {
  time: damlTypes.Time;
  migrationId: damlTypes.Int;
};

export declare const SynchronizerUpgradeSchedule:
  damlTypes.Serializable<SynchronizerUpgradeSchedule> & {
  }
;


export declare type DsoRulesConfig = {
  numUnclaimedRewardsThreshold: damlTypes.Int;
  numMemberTrafficContractsThreshold: damlTypes.Int;
  actionConfirmationTimeout: pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946.DA.Time.Types.RelTime;
  svOnboardingRequestTimeout: pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946.DA.Time.Types.RelTime;
  svOnboardingConfirmedTimeout: pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946.DA.Time.Types.RelTime;
  voteRequestTimeout: pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946.DA.Time.Types.RelTime;
  dsoDelegateInactiveTimeout: pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946.DA.Time.Types.RelTime;
  synchronizerNodeConfigLimits: Splice_DSO_DecentralizedSynchronizer.SynchronizerNodeConfigLimits;
  maxTextLength: damlTypes.Int;
  decentralizedSynchronizer: Splice_DSO_DecentralizedSynchronizer.DsoDecentralizedSynchronizerConfig;
  nextScheduledSynchronizerUpgrade: damlTypes.Optional<SynchronizerUpgradeSchedule>;
  voteCooldownTime: damlTypes.Optional<pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946.DA.Time.Types.RelTime>;
  nextScheduledLogicalSynchronizerUpgrade: damlTypes.Optional<LogicalSynchronizerUpgradeSchedule>;
};

export declare const DsoRulesConfig:
  damlTypes.Serializable<DsoRulesConfig> & {
  }
;


export declare type Reason = {
  url: string;
  body: string;
};

export declare const Reason:
  damlTypes.Serializable<Reason> & {
  }
;


export declare type Vote = {
  sv: damlTypes.Party;
  accept: boolean;
  reason: Reason;
  optCastAt: damlTypes.Optional<damlTypes.Time>;
};

export declare const Vote:
  damlTypes.Serializable<Vote> & {
  }
;


export declare type VoteRequestOutcome =
  |  { tag: 'VRO_AcceptedButActionFailed'; value: VoteRequestOutcome.VRO_AcceptedButActionFailed }
  |  { tag: 'VRO_Accepted'; value: VoteRequestOutcome.VRO_Accepted }
  |  { tag: 'VRO_Rejected'; value: {} }
  |  { tag: 'VRO_Expired'; value: {} }
  |  { tag: 'ExtVoteRequestOutcome'; value: VoteRequestOutcome.ExtVoteRequestOutcome }
;

export declare const VoteRequestOutcome:
  damlTypes.Serializable<VoteRequestOutcome> & {
  VRO_AcceptedButActionFailed: damlTypes.Serializable<VoteRequestOutcome.VRO_AcceptedButActionFailed>;
  VRO_Accepted: damlTypes.Serializable<VoteRequestOutcome.VRO_Accepted>;
  ExtVoteRequestOutcome: damlTypes.Serializable<VoteRequestOutcome.ExtVoteRequestOutcome>;
  }
;


export namespace VoteRequestOutcome {
  type VRO_AcceptedButActionFailed = {
    description: string;
  };
} //namespace VoteRequestOutcome


export namespace VoteRequestOutcome {
  type VRO_Accepted = {
    effectiveAt: damlTypes.Time;
  };
} //namespace VoteRequestOutcome


export namespace VoteRequestOutcome {
  type ExtVoteRequestOutcome = {
    dummyUnitField: {};
  };
} //namespace VoteRequestOutcome


export declare type DsoRules_BootstrapExternalPartyConfigStateResult =
  | 'DsoRules_BootstrapExternalPartyConfigStateResult'
;

export declare const DsoRules_BootstrapExternalPartyConfigStateResult:
  damlTypes.Serializable<DsoRules_BootstrapExternalPartyConfigStateResult> & {
  }
& { readonly keys: DsoRules_BootstrapExternalPartyConfigStateResult[] } & { readonly [e in DsoRules_BootstrapExternalPartyConfigStateResult]: e }
;


export declare type DsoRules_CloseVoteRequestResult = {
  request: VoteRequest;
  completedAt: damlTypes.Time;
  offboardedVoters: string[];
  abstainingSvs: string[];
  outcome: VoteRequestOutcome;
};

export declare const DsoRules_CloseVoteRequestResult:
  damlTypes.Serializable<DsoRules_CloseVoteRequestResult> & {
  }
;


export declare type VoteRequest = {
  dso: damlTypes.Party;
  requester: string;
  action: ActionRequiringConfirmation;
  reason: Reason;
  voteBefore: damlTypes.Time;
  votes: damlTypes.Map<string, Vote>;
  trackingCid: damlTypes.Optional<damlTypes.ContractId<VoteRequest>>;
  targetEffectiveAt: damlTypes.Optional<damlTypes.Time>;
};

export declare interface VoteRequestInterface {
  Archive: damlTypes.Choice<VoteRequest, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<VoteRequest, undefined>>;
}
export declare const VoteRequest:
  damlTypes.Template<VoteRequest, undefined, '#splice-dso-governance:Splice.DsoRules:VoteRequest'> &
  damlTypes.ToInterface<VoteRequest, never> &
  VoteRequestInterface;

export declare namespace VoteRequest {
}



export declare type Confirmation_Expire = {
};

export declare const Confirmation_Expire:
  damlTypes.Serializable<Confirmation_Expire> & {
  }
;


export declare type Confirmation = {
  dso: damlTypes.Party;
  confirmer: damlTypes.Party;
  action: ActionRequiringConfirmation;
  expiresAt: damlTypes.Time;
};

export declare interface ConfirmationInterface {
  Archive: damlTypes.Choice<Confirmation, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<Confirmation, undefined>>;
  Confirmation_Expire: damlTypes.Choice<Confirmation, Confirmation_Expire, Confirmation_ExpireResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<Confirmation, undefined>>;
}
export declare const Confirmation:
  damlTypes.Template<Confirmation, undefined, '#splice-dso-governance:Splice.DsoRules:Confirmation'> &
  damlTypes.ToInterface<Confirmation, never> &
  ConfirmationInterface;

export declare namespace Confirmation {
}



export declare type ElectionRequest = {
  dso: damlTypes.Party;
  requester: damlTypes.Party;
  epoch: damlTypes.Int;
  reason: ElectionRequestReason;
  ranking: damlTypes.Party[];
};

export declare interface ElectionRequestInterface {
  Archive: damlTypes.Choice<ElectionRequest, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<ElectionRequest, undefined>>;
}
export declare const ElectionRequest:
  damlTypes.Template<ElectionRequest, undefined, '#splice-dso-governance:Splice.DsoRules:ElectionRequest'> &
  damlTypes.ToInterface<ElectionRequest, never> &
  ElectionRequestInterface;

export declare namespace ElectionRequest {
}



export declare type ElectionRequestReason =
  |  { tag: 'ERR_DsoDelegateUnavailable'; value: {} }
  |  { tag: 'ERR_OtherReason'; value: string }
  |  { tag: 'ExtElectionRequestReason'; value: ElectionRequestReason.ExtElectionRequestReason }
;

export declare const ElectionRequestReason:
  damlTypes.Serializable<ElectionRequestReason> & {
  ExtElectionRequestReason: damlTypes.Serializable<ElectionRequestReason.ExtElectionRequestReason>;
  }
;


export namespace ElectionRequestReason {
  type ExtElectionRequestReason = {
    dummyUnitField: {};
  };
} //namespace ElectionRequestReason


export declare type DsoRules_ExpireAmuletAllocationsResult = {
  result: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.ExternalPartyAmuletRules.ExternalPartyAmuletRules_ExpireAmuletAllocationsResult;
};

export declare const DsoRules_ExpireAmuletAllocationsResult:
  damlTypes.Serializable<DsoRules_ExpireAmuletAllocationsResult> & {
  }
;


export declare type DsoRules_CreateBootstrapExternalPartyConfigStateInstructionResult = {
  instructionCid: damlTypes.ContractId<BootstrapExternalPartyConfigStateInstruction>;
};

export declare const DsoRules_CreateBootstrapExternalPartyConfigStateInstructionResult:
  damlTypes.Serializable<DsoRules_CreateBootstrapExternalPartyConfigStateInstructionResult> & {
  }
;


export declare type DsoRules_ExpireUnclaimedActivityRecordResult = {
  unclaimedRewardCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.UnclaimedReward>;
};

export declare const DsoRules_ExpireUnclaimedActivityRecordResult:
  damlTypes.Serializable<DsoRules_ExpireUnclaimedActivityRecordResult> & {
  }
;


export declare type DsoRules_ExpireUnallocatedUnclaimedActivityRecordResult =
  | 'DsoRules_ExpireUnallocatedUnclaimedActivityRecordResult'
;

export declare const DsoRules_ExpireUnallocatedUnclaimedActivityRecordResult:
  damlTypes.Serializable<DsoRules_ExpireUnallocatedUnclaimedActivityRecordResult> & {
  }
& { readonly keys: DsoRules_ExpireUnallocatedUnclaimedActivityRecordResult[] } & { readonly [e in DsoRules_ExpireUnallocatedUnclaimedActivityRecordResult]: e }
;


export declare type DsoRules_AllocateUnallocatedUnclaimedActivityRecordResult = {
  unclaimedActivityRecordCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.UnclaimedActivityRecord>;
  optUnclaimedRewardCid: damlTypes.Optional<damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.UnclaimedReward>>;
};

export declare const DsoRules_AllocateUnallocatedUnclaimedActivityRecordResult:
  damlTypes.Serializable<DsoRules_AllocateUnallocatedUnclaimedActivityRecordResult> & {
  }
;


export declare type DsoRules_CreateUnallocatedUnclaimedActivityRecordResult = {
  unallocatedUnclaimedActivityRecordCid: damlTypes.ContractId<UnallocatedUnclaimedActivityRecord>;
};

export declare const DsoRules_CreateUnallocatedUnclaimedActivityRecordResult:
  damlTypes.Serializable<DsoRules_CreateUnallocatedUnclaimedActivityRecordResult> & {
  }
;


export declare type DsoRules_AmuletRules_ConvertFeaturedAppActivityMarkersResult = {
  result: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules_ConvertFeaturedAppActivityMarkersResult;
};

export declare const DsoRules_AmuletRules_ConvertFeaturedAppActivityMarkersResult:
  damlTypes.Serializable<DsoRules_AmuletRules_ConvertFeaturedAppActivityMarkersResult> & {
  }
;


export declare type DsoRules_ExpireTransferPreapprovalResult =
  | 'DsoRules_ExpireTransferPreapprovalResult'
;

export declare const DsoRules_ExpireTransferPreapprovalResult:
  damlTypes.Serializable<DsoRules_ExpireTransferPreapprovalResult> & {
  }
& { readonly keys: DsoRules_ExpireTransferPreapprovalResult[] } & { readonly [e in DsoRules_ExpireTransferPreapprovalResult]: e }
;


export declare type DsoRules_CreateTransferCommandCounterResult = {
  transferCommandCounterCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.ExternalPartyAmuletRules.TransferCommandCounter>;
};

export declare const DsoRules_CreateTransferCommandCounterResult:
  damlTypes.Serializable<DsoRules_CreateTransferCommandCounterResult> & {
  }
;


export declare type DsoRules_CreateExternalPartyAmuletRulesResult = {
  externalPartyAmuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.ExternalPartyAmuletRules.ExternalPartyAmuletRules>;
};

export declare const DsoRules_CreateExternalPartyAmuletRulesResult:
  damlTypes.Serializable<DsoRules_CreateExternalPartyAmuletRulesResult> & {
  }
;


export declare type DsoRules_PruneAmuletConfigScheduleResult = {
  amuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>;
};

export declare const DsoRules_PruneAmuletConfigScheduleResult:
  damlTypes.Serializable<DsoRules_PruneAmuletConfigScheduleResult> & {
  }
;


export declare type DsoRules_MergeSvRewardStateResult = {
  svRewardState: damlTypes.ContractId<Splice_DSO_SvState.SvRewardState>;
};

export declare const DsoRules_MergeSvRewardStateResult:
  damlTypes.Serializable<DsoRules_MergeSvRewardStateResult> & {
  }
;


export declare type DsoRules_MergeMemberTrafficContractsResult = {
  memberTraffic: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.DecentralizedSynchronizer.MemberTraffic>;
};

export declare const DsoRules_MergeMemberTrafficContractsResult:
  damlTypes.Serializable<DsoRules_MergeMemberTrafficContractsResult> & {
  }
;


export declare type DsoRules_MiningRound_CloseResult = {
  closedRound: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Round.ClosedMiningRound>;
};

export declare const DsoRules_MiningRound_CloseResult:
  damlTypes.Serializable<DsoRules_MiningRound_CloseResult> & {
  }
;


export declare type DsoRules_ExpireDevelopmentFundCouponResult = {
  result: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.DevelopmentFundCoupon_DsoExpireResult;
};

export declare const DsoRules_ExpireDevelopmentFundCouponResult:
  damlTypes.Serializable<DsoRules_ExpireDevelopmentFundCouponResult> & {
  }
;


export declare type DsoRules_MergeUnclaimedDevelopmentFundCouponsResult = {
  result: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules_MergeUnclaimedDevelopmentFundCouponsResult;
};

export declare const DsoRules_MergeUnclaimedDevelopmentFundCouponsResult:
  damlTypes.Serializable<DsoRules_MergeUnclaimedDevelopmentFundCouponsResult> & {
  }
;


export declare type DsoRules_MergeUnclaimedRewardsResult = {
  unclaimedReward: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.UnclaimedReward>;
};

export declare const DsoRules_MergeUnclaimedRewardsResult:
  damlTypes.Serializable<DsoRules_MergeUnclaimedRewardsResult> & {
  }
;


export declare type DsoRules_ClaimExpiredRewardsResult = {
  unclaimedReward: damlTypes.Optional<damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.UnclaimedReward>>;
};

export declare const DsoRules_ClaimExpiredRewardsResult:
  damlTypes.Serializable<DsoRules_ClaimExpiredRewardsResult> & {
  }
;


export declare type DsoRules_ReceiveSvRewardCouponResult = {
  svRewardState: damlTypes.ContractId<Splice_DSO_SvState.SvRewardState>;
  svRewardCoupons: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.SvRewardCoupon>[];
};

export declare const DsoRules_ReceiveSvRewardCouponResult:
  damlTypes.Serializable<DsoRules_ReceiveSvRewardCouponResult> & {
  }
;


export declare type DsoRules_TerminateSubscriptionResult =
  | 'DsoRules_TerminateSubscriptionResult'
;

export declare const DsoRules_TerminateSubscriptionResult:
  damlTypes.Serializable<DsoRules_TerminateSubscriptionResult> & {
  }
& { readonly keys: DsoRules_TerminateSubscriptionResult[] } & { readonly [e in DsoRules_TerminateSubscriptionResult]: e }
;


export declare type DsoRules_ExpireSubscriptionResult =
  | 'DsoRules_ExpireSubscriptionResult'
;

export declare const DsoRules_ExpireSubscriptionResult:
  damlTypes.Serializable<DsoRules_ExpireSubscriptionResult> & {
  }
& { readonly keys: DsoRules_ExpireSubscriptionResult[] } & { readonly [e in DsoRules_ExpireSubscriptionResult]: e }
;


export declare type DsoRules_ExpireAnsEntryResult =
  | 'DsoRules_ExpireAnsEntryResult'
;

export declare const DsoRules_ExpireAnsEntryResult:
  damlTypes.Serializable<DsoRules_ExpireAnsEntryResult> & {
  }
& { readonly keys: DsoRules_ExpireAnsEntryResult[] } & { readonly [e in DsoRules_ExpireAnsEntryResult]: e }
;


export declare type DsoRules_CollectEntryRenewalPaymentResult = {
  ansEntry: damlTypes.ContractId<pkg7b784f7f03d3e035ea5d828ab64a476e7e0cbfffaec393619598f13e54d18013.Splice.Ans.AnsEntry>;
  subscriptionState: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionIdleState>;
};

export declare const DsoRules_CollectEntryRenewalPaymentResult:
  damlTypes.Serializable<DsoRules_CollectEntryRenewalPaymentResult> & {
  }
;


export declare type DsoRules_UpdateExternalPartyConfigStatesResult = {
  newExternalPartyConfigStateCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.ExternalPartyConfigState.ExternalPartyConfigState>;
};

export declare const DsoRules_UpdateExternalPartyConfigStatesResult:
  damlTypes.Serializable<DsoRules_UpdateExternalPartyConfigStatesResult> & {
  }
;


export declare type DsoRules_AdvanceOpenMiningRoundsResult = {
  summarizingRound: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Round.SummarizingMiningRound>;
  openRound: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Round.OpenMiningRound>;
};

export declare const DsoRules_AdvanceOpenMiningRoundsResult:
  damlTypes.Serializable<DsoRules_AdvanceOpenMiningRoundsResult> & {
  }
;


export declare type DsoRules_LockedAmulet_ExpireAmuletV2Result = {
  expireSum: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.AmuletExpireV2Summary;
};

export declare const DsoRules_LockedAmulet_ExpireAmuletV2Result:
  damlTypes.Serializable<DsoRules_LockedAmulet_ExpireAmuletV2Result> & {
  }
;


export declare type DsoRules_LockedAmulet_ExpireAmuletResult = {
  expireSum: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.AmuletExpireSummary;
};

export declare const DsoRules_LockedAmulet_ExpireAmuletResult:
  damlTypes.Serializable<DsoRules_LockedAmulet_ExpireAmuletResult> & {
  }
;


export declare type DsoRules_Amulet_ExpireV2Result = {
  expireSum: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.AmuletExpireV2Summary;
};

export declare const DsoRules_Amulet_ExpireV2Result:
  damlTypes.Serializable<DsoRules_Amulet_ExpireV2Result> & {
  }
;


export declare type DsoRules_Amulet_ExpireResult = {
  expireSum: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.AmuletExpireSummary;
};

export declare const DsoRules_Amulet_ExpireResult:
  damlTypes.Serializable<DsoRules_Amulet_ExpireResult> & {
  }
;


export declare type DsoRules_Amulet_ExpireTransferInstructionsResult = {
  result: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules_Amulet_ExpireTransferInstructionsResult;
};

export declare const DsoRules_Amulet_ExpireTransferInstructionsResult:
  damlTypes.Serializable<DsoRules_Amulet_ExpireTransferInstructionsResult> & {
  }
;


export declare type DsoRules_ExpireSvOnboardingConfirmedResult = {
  newDsoRules: damlTypes.ContractId<DsoRules>;
};

export declare const DsoRules_ExpireSvOnboardingConfirmedResult:
  damlTypes.Serializable<DsoRules_ExpireSvOnboardingConfirmedResult> & {
  }
;


export declare type DsoRules_ConfirmSvOnboardingResult = {
  onboardingConfirmed: damlTypes.ContractId<Splice_SvOnboarding.SvOnboardingConfirmed>;
};

export declare const DsoRules_ConfirmSvOnboardingResult:
  damlTypes.Serializable<DsoRules_ConfirmSvOnboardingResult> & {
  }
;


export declare type DsoRules_ArchiveSvOnboardingRequestResult =
  | 'DsoRules_ArchiveSvOnboardingRequestResult'
;

export declare const DsoRules_ArchiveSvOnboardingRequestResult:
  damlTypes.Serializable<DsoRules_ArchiveSvOnboardingRequestResult> & {
  }
& { readonly keys: DsoRules_ArchiveSvOnboardingRequestResult[] } & { readonly [e in DsoRules_ArchiveSvOnboardingRequestResult]: e }
;


export declare type DsoRules_ExpireSvOnboardingRequestResult =
  | 'DsoRules_ExpireSvOnboardingRequestResult'
;

export declare const DsoRules_ExpireSvOnboardingRequestResult:
  damlTypes.Serializable<DsoRules_ExpireSvOnboardingRequestResult> & {
  }
& { readonly keys: DsoRules_ExpireSvOnboardingRequestResult[] } & { readonly [e in DsoRules_ExpireSvOnboardingRequestResult]: e }
;


export declare type DsoRules_StartSvOnboardingResult = {
  onboardingRequest: damlTypes.ContractId<Splice_SvOnboarding.SvOnboardingRequest>;
};

export declare const DsoRules_StartSvOnboardingResult:
  damlTypes.Serializable<DsoRules_StartSvOnboardingResult> & {
  }
;


export declare type DsoRules_MergeValidatorLicenseResult = {
  validatorLicense: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.ValidatorLicense.ValidatorLicense>;
};

export declare const DsoRules_MergeValidatorLicenseResult:
  damlTypes.Serializable<DsoRules_MergeValidatorLicenseResult> & {
  }
;


export declare type DsoRules_OnboardValidatorResult = {
  validatorLicense: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.ValidatorLicense.ValidatorLicense>;
};

export declare const DsoRules_OnboardValidatorResult:
  damlTypes.Serializable<DsoRules_OnboardValidatorResult> & {
  }
;


export declare type DsoRules_RevokeFeaturedAppRightResult =
  | 'DsoRules_RevokeFeaturedAppRightResult'
;

export declare const DsoRules_RevokeFeaturedAppRightResult:
  damlTypes.Serializable<DsoRules_RevokeFeaturedAppRightResult> & {
  }
& { readonly keys: DsoRules_RevokeFeaturedAppRightResult[] } & { readonly [e in DsoRules_RevokeFeaturedAppRightResult]: e }
;


export declare type DsoRules_GrantFeaturedAppRightResult = {
  featuredAppRight: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.FeaturedAppRight>;
};

export declare const DsoRules_GrantFeaturedAppRightResult:
  damlTypes.Serializable<DsoRules_GrantFeaturedAppRightResult> & {
  }
;


export declare type DsoRules_UpdateSvRewardWeightResult = {
  newDsoRules: damlTypes.ContractId<DsoRules>;
};

export declare const DsoRules_UpdateSvRewardWeightResult:
  damlTypes.Serializable<DsoRules_UpdateSvRewardWeightResult> & {
  }
;


export declare type DsoRules_SetConfigResult = {
  newDsoRules: damlTypes.ContractId<DsoRules>;
};

export declare const DsoRules_SetConfigResult:
  damlTypes.Serializable<DsoRules_SetConfigResult> & {
  }
;


export declare type DsoRules_GarbageCollectAmuletPriceVotesResult =
  | 'DsoRules_GarbageCollectAmuletPriceVotesResult'
;

export declare const DsoRules_GarbageCollectAmuletPriceVotesResult:
  damlTypes.Serializable<DsoRules_GarbageCollectAmuletPriceVotesResult> & {
  }
& { readonly keys: DsoRules_GarbageCollectAmuletPriceVotesResult[] } & { readonly [e in DsoRules_GarbageCollectAmuletPriceVotesResult]: e }
;


export declare type DsoRules_UpdateAmuletPriceVoteResult = {
  amuletPriceVote: damlTypes.ContractId<Splice_DSO_AmuletPrice.AmuletPriceVote>;
};

export declare const DsoRules_UpdateAmuletPriceVoteResult:
  damlTypes.Serializable<DsoRules_UpdateAmuletPriceVoteResult> & {
  }
;


export declare type DsoRules_CastVoteResult = {
  voteRequest: damlTypes.ContractId<VoteRequest>;
};

export declare const DsoRules_CastVoteResult:
  damlTypes.Serializable<DsoRules_CastVoteResult> & {
  }
;


export declare type DsoRules_RequestVoteResult = {
  voteRequest: damlTypes.ContractId<VoteRequest>;
};

export declare const DsoRules_RequestVoteResult:
  damlTypes.Serializable<DsoRules_RequestVoteResult> & {
  }
;


export declare type DsoRules_ExpireStaleConfirmationResult =
  | 'DsoRules_ExpireStaleConfirmationResult'
;

export declare const DsoRules_ExpireStaleConfirmationResult:
  damlTypes.Serializable<DsoRules_ExpireStaleConfirmationResult> & {
  }
& { readonly keys: DsoRules_ExpireStaleConfirmationResult[] } & { readonly [e in DsoRules_ExpireStaleConfirmationResult]: e }
;


export declare type DsoRules_ExecuteConfirmedActionResult =
  | 'DsoRules_ExecuteConfirmedActionResult'
;

export declare const DsoRules_ExecuteConfirmedActionResult:
  damlTypes.Serializable<DsoRules_ExecuteConfirmedActionResult> & {
  }
& { readonly keys: DsoRules_ExecuteConfirmedActionResult[] } & { readonly [e in DsoRules_ExecuteConfirmedActionResult]: e }
;


export declare type DsoRules_ConfirmActionResult = {
  confirmation: damlTypes.ContractId<Confirmation>;
};

export declare const DsoRules_ConfirmActionResult:
  damlTypes.Serializable<DsoRules_ConfirmActionResult> & {
  }
;


export declare type DsoRules_ArchiveOutdatedElectionRequestResult =
  | 'DsoRules_ArchiveOutdatedElectionRequestResult'
;

export declare const DsoRules_ArchiveOutdatedElectionRequestResult:
  damlTypes.Serializable<DsoRules_ArchiveOutdatedElectionRequestResult> & {
  }
& { readonly keys: DsoRules_ArchiveOutdatedElectionRequestResult[] } & { readonly [e in DsoRules_ArchiveOutdatedElectionRequestResult]: e }
;


export declare type DsoRules_ElectDsoDelegateResult = {
  newDsoRules: damlTypes.ContractId<DsoRules>;
};

export declare const DsoRules_ElectDsoDelegateResult:
  damlTypes.Serializable<DsoRules_ElectDsoDelegateResult> & {
  }
;


export declare type DsoRules_RequestElectionResult = {
  electionRequestCid: damlTypes.ContractId<ElectionRequest>;
};

export declare const DsoRules_RequestElectionResult:
  damlTypes.Serializable<DsoRules_RequestElectionResult> & {
  }
;


export declare type DsoRules_SetSynchronizerNodeConfigResult = {
  svNodeState: damlTypes.ContractId<Splice_DSO_SvState.SvNodeState>;
};

export declare const DsoRules_SetSynchronizerNodeConfigResult:
  damlTypes.Serializable<DsoRules_SetSynchronizerNodeConfigResult> & {
  }
;


export declare type DsoRules_AddConfirmedSvResult = {
  newDsoRules: damlTypes.ContractId<DsoRules>;
};

export declare const DsoRules_AddConfirmedSvResult:
  damlTypes.Serializable<DsoRules_AddConfirmedSvResult> & {
  }
;


export declare type DsoRules_SubmitStatusReportResult = {
  newReport: damlTypes.ContractId<Splice_DSO_SvState.SvStatusReport>;
};

export declare const DsoRules_SubmitStatusReportResult:
  damlTypes.Serializable<DsoRules_SubmitStatusReportResult> & {
  }
;


export declare type DsoRules_OffboardSvResult = {
  newDsoRules: damlTypes.ContractId<DsoRules>;
};

export declare const DsoRules_OffboardSvResult:
  damlTypes.Serializable<DsoRules_OffboardSvResult> & {
  }
;


export declare type DsoRules_AddSvResult = {
  newDsoRules: damlTypes.ContractId<DsoRules>;
};

export declare const DsoRules_AddSvResult:
  damlTypes.Serializable<DsoRules_AddSvResult> & {
  }
;


export declare type Confirmation_ExpireResult =
  | 'Confirmation_ExpireResult'
;

export declare const Confirmation_ExpireResult:
  damlTypes.Serializable<Confirmation_ExpireResult> & {
  }
& { readonly keys: Confirmation_ExpireResult[] } & { readonly [e in Confirmation_ExpireResult]: e }
;


export declare type DsoSummary = {
  dsoDelegate: damlTypes.Party;
  numSvs: damlTypes.Int;
  requiredNumVotes: damlTypes.Int;
};

export declare const DsoSummary:
  damlTypes.Serializable<DsoSummary> & {
  }
;


export declare type OffboardedSvInfo = {
  name: string;
  participantId: string;
};

export declare const OffboardedSvInfo:
  damlTypes.Serializable<OffboardedSvInfo> & {
  }
;


export declare type SvInfo = {
  name: string;
  joinedAsOfRound: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Types.Round;
  svRewardWeight: damlTypes.Int;
  participantId: string;
};

export declare const SvInfo:
  damlTypes.Serializable<SvInfo> & {
  }
;


export declare type AnsEntryContext_ActionRequiringConfirmation =
  |  { tag: 'ANSRARC_CollectInitialEntryPayment'; value: pkg7b784f7f03d3e035ea5d828ab64a476e7e0cbfffaec393619598f13e54d18013.Splice.Ans.AnsEntryContext_CollectInitialEntryPayment }
  |  { tag: 'ANSRARC_RejectEntryInitialPayment'; value: pkg7b784f7f03d3e035ea5d828ab64a476e7e0cbfffaec393619598f13e54d18013.Splice.Ans.AnsEntryContext_RejectEntryInitialPayment }
;

export declare const AnsEntryContext_ActionRequiringConfirmation:
  damlTypes.Serializable<AnsEntryContext_ActionRequiringConfirmation> & {
  }
;


export declare type DsoRules_ActionRequiringConfirmation =
  |  { tag: 'SRARC_AddSv'; value: DsoRules_AddSv }
  |  { tag: 'SRARC_OffboardSv'; value: DsoRules_OffboardSv }
  |  { tag: 'SRARC_ConfirmSvOnboarding'; value: DsoRules_ConfirmSvOnboarding }
  |  { tag: 'SRARC_GrantFeaturedAppRight'; value: DsoRules_GrantFeaturedAppRight }
  |  { tag: 'SRARC_RevokeFeaturedAppRight'; value: DsoRules_RevokeFeaturedAppRight }
  |  { tag: 'SRARC_SetConfig'; value: DsoRules_SetConfig }
  |  { tag: 'SRARC_UpdateSvRewardWeight'; value: DsoRules_UpdateSvRewardWeight }
  |  { tag: 'SRARC_CreateExternalPartyAmuletRules'; value: DsoRules_CreateExternalPartyAmuletRules }
  |  { tag: 'SRARC_CreateTransferCommandCounter'; value: DsoRules_CreateTransferCommandCounter }
  |  { tag: 'SRARC_CreateUnallocatedUnclaimedActivityRecord'; value: DsoRules_CreateUnallocatedUnclaimedActivityRecord }
  |  { tag: 'SRARC_CreateBootstrapExternalPartyConfigStateInstruction'; value: DsoRules_CreateBootstrapExternalPartyConfigStateInstruction }
;

export declare const DsoRules_ActionRequiringConfirmation:
  damlTypes.Serializable<DsoRules_ActionRequiringConfirmation> & {
  }
;


export declare type AmuletRules_ActionRequiringConfirmation =
  |  { tag: 'CRARC_MiningRound_StartIssuing'; value: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules_MiningRound_StartIssuing }
  |  { tag: 'CRARC_MiningRound_Archive'; value: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules_MiningRound_Archive }
  |  { tag: 'CRARC_AddFutureAmuletConfigSchedule'; value: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules_AddFutureAmuletConfigSchedule }
  |  { tag: 'CRARC_RemoveFutureAmuletConfigSchedule'; value: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules_RemoveFutureAmuletConfigSchedule }
  |  { tag: 'CRARC_UpdateFutureAmuletConfigSchedule'; value: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules_UpdateFutureAmuletConfigSchedule }
  |  { tag: 'CRARC_SetConfig'; value: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules_SetConfig }
;

export declare const AmuletRules_ActionRequiringConfirmation:
  damlTypes.Serializable<AmuletRules_ActionRequiringConfirmation> & {
  }
;


export declare type ActionRequiringConfirmation =
  |  { tag: 'ARC_DsoRules'; value: ActionRequiringConfirmation.ARC_DsoRules }
  |  { tag: 'ARC_AmuletRules'; value: ActionRequiringConfirmation.ARC_AmuletRules }
  |  { tag: 'ARC_AnsEntryContext'; value: ActionRequiringConfirmation.ARC_AnsEntryContext }
  |  { tag: 'ExtActionRequiringConformation'; value: ActionRequiringConfirmation.ExtActionRequiringConformation }
;

export declare const ActionRequiringConfirmation:
  damlTypes.Serializable<ActionRequiringConfirmation> & {
  ARC_DsoRules: damlTypes.Serializable<ActionRequiringConfirmation.ARC_DsoRules>;
  ARC_AmuletRules: damlTypes.Serializable<ActionRequiringConfirmation.ARC_AmuletRules>;
  ARC_AnsEntryContext: damlTypes.Serializable<ActionRequiringConfirmation.ARC_AnsEntryContext>;
  ExtActionRequiringConformation: damlTypes.Serializable<ActionRequiringConfirmation.ExtActionRequiringConformation>;
  }
;


export namespace ActionRequiringConfirmation {
  type ARC_DsoRules = {
    dsoAction: DsoRules_ActionRequiringConfirmation;
  };
} //namespace ActionRequiringConfirmation


export namespace ActionRequiringConfirmation {
  type ARC_AmuletRules = {
    amuletRulesAction: AmuletRules_ActionRequiringConfirmation;
  };
} //namespace ActionRequiringConfirmation


export namespace ActionRequiringConfirmation {
  type ARC_AnsEntryContext = {
    ansEntryContextCid: damlTypes.ContractId<pkg7b784f7f03d3e035ea5d828ab64a476e7e0cbfffaec393619598f13e54d18013.Splice.Ans.AnsEntryContext>;
    ansEntryContextAction: AnsEntryContext_ActionRequiringConfirmation;
  };
} //namespace ActionRequiringConfirmation


export namespace ActionRequiringConfirmation {
  type ExtActionRequiringConformation = {
    dummyUnitField: {};
  };
} //namespace ActionRequiringConfirmation

