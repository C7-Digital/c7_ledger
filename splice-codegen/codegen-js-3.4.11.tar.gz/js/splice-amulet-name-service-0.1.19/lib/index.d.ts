import * as Splice from './Splice';
export { Splice } ;
export declare const packageId = '7b784f7f03d3e035ea5d828ab64a476e7e0cbfffaec393619598f13e54d18013';
