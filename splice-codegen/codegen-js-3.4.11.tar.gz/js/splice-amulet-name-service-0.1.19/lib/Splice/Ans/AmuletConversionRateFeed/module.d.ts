// Generated from Splice/Ans/AmuletConversionRateFeed.daml
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/no-use-before-define */
import * as jtv from '@mojotech/json-type-validation';
import * as damlTypes from '@daml/types';

import * as pkg7804375fe5e4c6d5afe067bd314c42fe0b7d005a1300019c73154dd939da4dda from '@c7-digital/splice-codegen/splice-api-featured-app-v1-1.0.0';
import * as pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69 from '@c7-digital/splice-codegen/ghc-stdlib-DA-Internal-Template-1.0.0';
import * as pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a from '@c7-digital/splice-codegen/splice-amulet-0.1.18';

export declare type AmuletConversionRateFeed_UpdateResult = {
  cid: damlTypes.ContractId<AmuletConversionRateFeed>;
};

export declare const AmuletConversionRateFeed_UpdateResult:
  damlTypes.Serializable<AmuletConversionRateFeed_UpdateResult> & {
  }
;


export declare type AmuletConversionRateFeed_ArchiveAsDsoResult =
  | 'AmuletConversionRateFeed_ArchiveAsDsoResult'
;

export declare const AmuletConversionRateFeed_ArchiveAsDsoResult:
  damlTypes.Serializable<AmuletConversionRateFeed_ArchiveAsDsoResult> & {
  }
& { readonly keys: AmuletConversionRateFeed_ArchiveAsDsoResult[] } & { readonly [e in AmuletConversionRateFeed_ArchiveAsDsoResult]: e }
;


export declare type AmuletConversionRateFeed_Update = {
  amuletConversionRate: damlTypes.Numeric;
  amuletRulesCid: damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AmuletRules>;
  markerContextO: damlTypes.Optional<MarkerContext>;
  newNextUpdateAfter: damlTypes.Time;
};

export declare const AmuletConversionRateFeed_Update:
  damlTypes.Serializable<AmuletConversionRateFeed_Update> & {
  }
;


export declare type AmuletConversionRateFeed_ArchiveAsDso = {
  reason: string;
};

export declare const AmuletConversionRateFeed_ArchiveAsDso:
  damlTypes.Serializable<AmuletConversionRateFeed_ArchiveAsDso> & {
  }
;


export declare type AmuletConversionRateFeed = {
  publisher: damlTypes.Party;
  dso: damlTypes.Party;
  nextUpdateAfter: damlTypes.Optional<damlTypes.Time>;
  amuletConversionRate: damlTypes.Numeric;
};

export declare interface AmuletConversionRateFeedInterface {
  AmuletConversionRateFeed_ArchiveAsDso: damlTypes.Choice<AmuletConversionRateFeed, AmuletConversionRateFeed_ArchiveAsDso, AmuletConversionRateFeed_ArchiveAsDsoResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AmuletConversionRateFeed, undefined>>;
  Archive: damlTypes.Choice<AmuletConversionRateFeed, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AmuletConversionRateFeed, undefined>>;
  AmuletConversionRateFeed_Update: damlTypes.Choice<AmuletConversionRateFeed, AmuletConversionRateFeed_Update, AmuletConversionRateFeed_UpdateResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AmuletConversionRateFeed, undefined>>;
}
export declare const AmuletConversionRateFeed:
  damlTypes.Template<AmuletConversionRateFeed, undefined, '#splice-amulet-name-service:Splice.Ans.AmuletConversionRateFeed:AmuletConversionRateFeed'> &
  damlTypes.ToInterface<AmuletConversionRateFeed, never> &
  AmuletConversionRateFeedInterface;

export declare namespace AmuletConversionRateFeed {
}



export declare type MarkerContext = {
  featuredAppRightCid: damlTypes.ContractId<pkg7804375fe5e4c6d5afe067bd314c42fe0b7d005a1300019c73154dd939da4dda.Splice.Api.FeaturedAppRightV1.FeaturedAppRight>;
  beneficiaries: pkg7804375fe5e4c6d5afe067bd314c42fe0b7d005a1300019c73154dd939da4dda.Splice.Api.FeaturedAppRightV1.AppRewardBeneficiary[];
};

export declare const MarkerContext:
  damlTypes.Serializable<MarkerContext> & {
  }
;

