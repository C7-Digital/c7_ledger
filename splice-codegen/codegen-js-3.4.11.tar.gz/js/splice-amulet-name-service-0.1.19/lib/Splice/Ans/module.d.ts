// Generated from Splice/Ans.daml
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/no-use-before-define */
import * as jtv from '@mojotech/json-type-validation';
import * as damlTypes from '@daml/types';

import * as pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8 from '@c7-digital/splice-codegen/splice-wallet-payments-0.1.18';
import * as pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69 from '@c7-digital/splice-codegen/ghc-stdlib-DA-Internal-Template-1.0.0';
import * as pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a from '@c7-digital/splice-codegen/splice-amulet-0.1.18';
import * as pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946 from '@c7-digital/splice-codegen/daml-stdlib-DA-Time-Types-1.0.0';

export declare type AnsEntry_Renew = {
  extension: pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946.DA.Time.Types.RelTime;
};

export declare const AnsEntry_Renew:
  damlTypes.Serializable<AnsEntry_Renew> & {
  }
;


export declare type AnsEntry_Expire = {
  actor: damlTypes.Party;
};

export declare const AnsEntry_Expire:
  damlTypes.Serializable<AnsEntry_Expire> & {
  }
;


export declare type AnsEntry = {
  user: damlTypes.Party;
  dso: damlTypes.Party;
  name: string;
  url: string;
  description: string;
  expiresAt: damlTypes.Time;
};

export declare interface AnsEntryInterface {
  AnsEntry_Renew: damlTypes.Choice<AnsEntry, AnsEntry_Renew, AnsEntry_RenewResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AnsEntry, undefined>>;
  AnsEntry_Expire: damlTypes.Choice<AnsEntry, AnsEntry_Expire, AnsEntry_ExpireResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AnsEntry, undefined>>;
  Archive: damlTypes.Choice<AnsEntry, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AnsEntry, undefined>>;
}
export declare const AnsEntry:
  damlTypes.Template<AnsEntry, undefined, '#splice-amulet-name-service:Splice.Ans:AnsEntry'> &
  damlTypes.ToInterface<AnsEntry, never> &
  AnsEntryInterface;

export declare namespace AnsEntry {
}



export declare type AnsEntryContext_RejectEntryInitialPayment = {
  paymentCid: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionInitialPayment>;
  transferContext: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AppTransferContext;
  ansRulesCid: damlTypes.ContractId<AnsRules>;
};

export declare const AnsEntryContext_RejectEntryInitialPayment:
  damlTypes.Serializable<AnsEntryContext_RejectEntryInitialPayment> & {
  }
;


export declare type AnsEntryContext_CollectEntryRenewalPayment = {
  paymentCid: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionPayment>;
  entryCid: damlTypes.ContractId<AnsEntry>;
  transferContext: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AppTransferContext;
  ansRulesCid: damlTypes.ContractId<AnsRules>;
};

export declare const AnsEntryContext_CollectEntryRenewalPayment:
  damlTypes.Serializable<AnsEntryContext_CollectEntryRenewalPayment> & {
  }
;


export declare type AnsEntryContext_CollectInitialEntryPayment = {
  paymentCid: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionInitialPayment>;
  transferContext: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AppTransferContext;
  ansRulesCid: damlTypes.ContractId<AnsRules>;
};

export declare const AnsEntryContext_CollectInitialEntryPayment:
  damlTypes.Serializable<AnsEntryContext_CollectInitialEntryPayment> & {
  }
;


export declare type AnsEntryContext_Terminate = {
  actor: damlTypes.Party;
  terminatedSubscriptionCid: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.TerminatedSubscription>;
};

export declare const AnsEntryContext_Terminate:
  damlTypes.Serializable<AnsEntryContext_Terminate> & {
  }
;


export declare type AnsEntryContext = {
  dso: damlTypes.Party;
  user: damlTypes.Party;
  name: string;
  url: string;
  description: string;
  reference: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionRequest>;
};

export declare interface AnsEntryContextInterface {
  AnsEntryContext_Terminate: damlTypes.Choice<AnsEntryContext, AnsEntryContext_Terminate, AnsEntryContext_TerminateResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AnsEntryContext, undefined>>;
  AnsEntryContext_CollectInitialEntryPayment: damlTypes.Choice<AnsEntryContext, AnsEntryContext_CollectInitialEntryPayment, AnsEntryContext_CollectInitialEntryPaymentResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AnsEntryContext, undefined>>;
  AnsEntryContext_CollectEntryRenewalPayment: damlTypes.Choice<AnsEntryContext, AnsEntryContext_CollectEntryRenewalPayment, AnsEntryContext_CollectEntryRenewalPaymentResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AnsEntryContext, undefined>>;
  AnsEntryContext_RejectEntryInitialPayment: damlTypes.Choice<AnsEntryContext, AnsEntryContext_RejectEntryInitialPayment, AnsEntryContext_RejectEntryInitialPaymentResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AnsEntryContext, undefined>>;
  Archive: damlTypes.Choice<AnsEntryContext, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AnsEntryContext, undefined>>;
}
export declare const AnsEntryContext:
  damlTypes.Template<AnsEntryContext, undefined, '#splice-amulet-name-service:Splice.Ans:AnsEntryContext'> &
  damlTypes.ToInterface<AnsEntryContext, never> &
  AnsEntryContextInterface;

export declare namespace AnsEntryContext {
}



export declare type AnsRulesConfig = {
  renewalDuration: pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946.DA.Time.Types.RelTime;
  entryLifetime: pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946.DA.Time.Types.RelTime;
  entryFee: damlTypes.Numeric;
  descriptionPrefix: string;
};

export declare const AnsRulesConfig:
  damlTypes.Serializable<AnsRulesConfig> & {
  }
;


export declare type ExpectedEntryContext = {
  dso: damlTypes.Party;
  user: damlTypes.Party;
  reference: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionRequest>;
};

export declare const ExpectedEntryContext:
  damlTypes.Serializable<ExpectedEntryContext> & {
  }
;


export declare type ExpectedPayment = {
  dso: damlTypes.Party;
  sender: damlTypes.Party;
};

export declare const ExpectedPayment:
  damlTypes.Serializable<ExpectedPayment> & {
  }
;


export declare type AnsRules_RejectEntryInitialPayment = {
  paymentCid: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionInitialPayment>;
  transferContext: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AppTransferContext;
};

export declare const AnsRules_RejectEntryInitialPayment:
  damlTypes.Serializable<AnsRules_RejectEntryInitialPayment> & {
  }
;


export declare type AnsRules_CollectEntryRenewalPayment = {
  user: damlTypes.Party;
  entryContext: damlTypes.ContractId<AnsEntryContext>;
  paymentCid: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionPayment>;
  entryCid: damlTypes.ContractId<AnsEntry>;
  transferContext: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AppTransferContext;
};

export declare const AnsRules_CollectEntryRenewalPayment:
  damlTypes.Serializable<AnsRules_CollectEntryRenewalPayment> & {
  }
;


export declare type AnsRules_CollectInitialEntryPayment = {
  user: damlTypes.Party;
  entryContext: damlTypes.ContractId<AnsEntryContext>;
  paymentCid: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionInitialPayment>;
  transferContext: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.AmuletRules.AppTransferContext;
};

export declare const AnsRules_CollectInitialEntryPayment:
  damlTypes.Serializable<AnsRules_CollectInitialEntryPayment> & {
  }
;


export declare type AnsRules_RequestEntry = {
  name: string;
  url: string;
  description: string;
  user: damlTypes.Party;
};

export declare const AnsRules_RequestEntry:
  damlTypes.Serializable<AnsRules_RequestEntry> & {
  }
;


export declare type AnsRules = {
  dso: damlTypes.Party;
  config: AnsRulesConfig;
};

export declare interface AnsRulesInterface {
  AnsRules_RequestEntry: damlTypes.Choice<AnsRules, AnsRules_RequestEntry, AnsRules_RequestEntryResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AnsRules, undefined>>;
  AnsRules_CollectInitialEntryPayment: damlTypes.Choice<AnsRules, AnsRules_CollectInitialEntryPayment, AnsRules_CollectInitialEntryPaymentResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AnsRules, undefined>>;
  AnsRules_CollectEntryRenewalPayment: damlTypes.Choice<AnsRules, AnsRules_CollectEntryRenewalPayment, AnsRules_CollectEntryRenewalPaymentResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AnsRules, undefined>>;
  AnsRules_RejectEntryInitialPayment: damlTypes.Choice<AnsRules, AnsRules_RejectEntryInitialPayment, AnsRules_RejectEntryInitialPaymentResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AnsRules, undefined>>;
  Archive: damlTypes.Choice<AnsRules, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AnsRules, undefined>>;
}
export declare const AnsRules:
  damlTypes.Template<AnsRules, undefined, '#splice-amulet-name-service:Splice.Ans:AnsRules'> &
  damlTypes.ToInterface<AnsRules, never> &
  AnsRulesInterface;

export declare namespace AnsRules {
}



export declare type AnsEntry_RenewResult = {
  entryCid: damlTypes.ContractId<AnsEntry>;
};

export declare const AnsEntry_RenewResult:
  damlTypes.Serializable<AnsEntry_RenewResult> & {
  }
;


export declare type AnsEntry_ExpireResult = {
};

export declare const AnsEntry_ExpireResult:
  damlTypes.Serializable<AnsEntry_ExpireResult> & {
  }
;


export declare type AnsEntryContext_TerminateResult = {
};

export declare const AnsEntryContext_TerminateResult:
  damlTypes.Serializable<AnsEntryContext_TerminateResult> & {
  }
;


export declare type AnsEntryContext_RejectEntryInitialPaymentResult = {
  amuletSum: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.AmuletCreateSummary<damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.Amulet>>;
};

export declare const AnsEntryContext_RejectEntryInitialPaymentResult:
  damlTypes.Serializable<AnsEntryContext_RejectEntryInitialPaymentResult> & {
  }
;


export declare type AnsEntryContext_CollectEntryRenewalPaymentResult = {
  entryCid: damlTypes.ContractId<AnsEntry>;
  subscriptionStateCid: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionIdleState>;
};

export declare const AnsEntryContext_CollectEntryRenewalPaymentResult:
  damlTypes.Serializable<AnsEntryContext_CollectEntryRenewalPaymentResult> & {
  }
;


export declare type AnsRules_RejectEntryInitialPaymentResult = {
  amuletSum: pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.AmuletCreateSummary<damlTypes.ContractId<pkga31be0483f3175647053f28965a4e6d97e3dbc433ea2338be303fae69bbcff6a.Splice.Amulet.Amulet>>;
};

export declare const AnsRules_RejectEntryInitialPaymentResult:
  damlTypes.Serializable<AnsRules_RejectEntryInitialPaymentResult> & {
  }
;


export declare type AnsRules_CollectEntryRenewalPaymentResult = {
  entryCid: damlTypes.ContractId<AnsEntry>;
  subscriptionStateCid: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionIdleState>;
};

export declare const AnsRules_CollectEntryRenewalPaymentResult:
  damlTypes.Serializable<AnsRules_CollectEntryRenewalPaymentResult> & {
  }
;


export declare type AnsEntryContext_CollectInitialEntryPaymentResult = {
  entryCid: damlTypes.ContractId<AnsEntry>;
  subscriptionStateCid: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionIdleState>;
};

export declare const AnsEntryContext_CollectInitialEntryPaymentResult:
  damlTypes.Serializable<AnsEntryContext_CollectInitialEntryPaymentResult> & {
  }
;


export declare type AnsRules_CollectInitialEntryPaymentResult = {
  entryCid: damlTypes.ContractId<AnsEntry>;
  subscriptionStateCid: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionIdleState>;
};

export declare const AnsRules_CollectInitialEntryPaymentResult:
  damlTypes.Serializable<AnsRules_CollectInitialEntryPaymentResult> & {
  }
;


export declare type AnsRules_RequestEntryResult = {
  entryCid: damlTypes.ContractId<AnsEntryContext>;
  requestCid: damlTypes.ContractId<pkg06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8.Splice.Wallet.Subscriptions.SubscriptionRequest>;
};

export declare const AnsRules_RequestEntryResult:
  damlTypes.Serializable<AnsRules_RequestEntryResult> & {
  }
;

