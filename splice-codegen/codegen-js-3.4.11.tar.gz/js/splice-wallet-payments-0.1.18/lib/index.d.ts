import * as Splice from './Splice';
export { Splice } ;
export declare const packageId = '06afd4996294b3763b10fc7ed3b2b216dc3ff2196264cf7d62d0572dd3b737b8';
