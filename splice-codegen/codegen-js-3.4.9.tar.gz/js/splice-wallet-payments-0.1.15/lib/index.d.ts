import * as Splice from './Splice';
export { Splice } ;
export declare const packageId = 'f80fae7a9de9431854372a66c3ca78675f77b2f54ede65abdc1b1abdec707d21';
