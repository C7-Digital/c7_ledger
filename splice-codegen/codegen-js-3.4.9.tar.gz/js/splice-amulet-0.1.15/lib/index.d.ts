import * as Splice from './Splice';
export { Splice } ;
export declare const packageId = '67fac2f853bce8dbf0b9817bb5ba7c59f10e8120b7c808696f7010e5f0c8a791';
