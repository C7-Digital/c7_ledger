// Generated from Splice/CometBft.daml
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/no-use-before-define */
import * as jtv from '@mojotech/json-type-validation';
import * as damlTypes from '@daml/types';

export declare type CometBftConfigLimits = {
  maxNumCometBftNodes: damlTypes.Int;
  maxNumGovernanceKeys: damlTypes.Int;
  maxNumSequencingKeys: damlTypes.Int;
  maxNodeIdLength: damlTypes.Int;
  maxPubKeyLength: damlTypes.Int;
};

export declare const CometBftConfigLimits:
  damlTypes.Serializable<CometBftConfigLimits> & {
  }
;


export declare type CometBftConfig = {
  nodes: damlTypes.Map<string, CometBftNodeConfig>;
  governanceKeys: GovernanceKeyConfig[];
  sequencingKeys: SequencingKeyConfig[];
};

export declare const CometBftConfig:
  damlTypes.Serializable<CometBftConfig> & {
  }
;


export declare type SequencingKeyConfig = {
  pubKey: string;
};

export declare const SequencingKeyConfig:
  damlTypes.Serializable<SequencingKeyConfig> & {
  }
;


export declare type GovernanceKeyConfig = {
  pubKey: string;
};

export declare const GovernanceKeyConfig:
  damlTypes.Serializable<GovernanceKeyConfig> & {
  }
;


export declare type CometBftNodeConfig = {
  validatorPubKey: string;
  votingPower: damlTypes.Int;
};

export declare const CometBftNodeConfig:
  damlTypes.Serializable<CometBftNodeConfig> & {
  }
;

