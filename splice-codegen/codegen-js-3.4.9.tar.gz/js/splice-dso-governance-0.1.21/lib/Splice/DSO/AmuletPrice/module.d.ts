// Generated from Splice/DSO/AmuletPrice.daml
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/no-use-before-define */
import * as jtv from '@mojotech/json-type-validation';
import * as damlTypes from '@daml/types';

import * as pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69 from '@c7-digital/splice-codegen/ghc-stdlib-DA-Internal-Template-1.0.0';

export declare type AmuletPriceVote = {
  dso: damlTypes.Party;
  sv: damlTypes.Party;
  amuletPrice: damlTypes.Optional<damlTypes.Numeric>;
  lastUpdatedAt: damlTypes.Time;
};

export declare interface AmuletPriceVoteInterface {
  Archive: damlTypes.Choice<AmuletPriceVote, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<AmuletPriceVote, undefined>>;
}
export declare const AmuletPriceVote:
  damlTypes.Template<AmuletPriceVote, undefined, '#splice-dso-governance:Splice.DSO.AmuletPrice:AmuletPriceVote'> &
  damlTypes.ToInterface<AmuletPriceVote, never> &
  AmuletPriceVoteInterface;

export declare namespace AmuletPriceVote {
}


