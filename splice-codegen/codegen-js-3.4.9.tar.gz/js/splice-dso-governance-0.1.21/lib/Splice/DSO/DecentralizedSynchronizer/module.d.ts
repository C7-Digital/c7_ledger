// Generated from Splice/DSO/DecentralizedSynchronizer.daml
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/no-use-before-define */
import * as jtv from '@mojotech/json-type-validation';
import * as damlTypes from '@daml/types';

import * as Splice_CometBft from '../../../Splice/CometBft/module';

export declare type SynchronizerNodeConfigLimits = {
  cometBft: Splice_CometBft.CometBftConfigLimits;
};

export declare const SynchronizerNodeConfigLimits:
  damlTypes.Serializable<SynchronizerNodeConfigLimits> & {
  }
;


export declare type SynchronizerNodeConfig = {
  cometBft: Splice_CometBft.CometBftConfig;
  sequencer: damlTypes.Optional<SequencerConfig>;
  mediator: damlTypes.Optional<MediatorConfig>;
  scan: damlTypes.Optional<ScanConfig>;
  legacySequencerConfig: damlTypes.Optional<LegacySequencerConfig>;
};

export declare const SynchronizerNodeConfig:
  damlTypes.Serializable<SynchronizerNodeConfig> & {
  }
;


export declare type ScanConfig = {
  publicUrl: string;
};

export declare const ScanConfig:
  damlTypes.Serializable<ScanConfig> & {
  }
;


export declare type MediatorConfig = {
  mediatorId: string;
};

export declare const MediatorConfig:
  damlTypes.Serializable<MediatorConfig> & {
  }
;


export declare type LegacySequencerConfig = {
  migrationId: damlTypes.Int;
  sequencerId: string;
  url: string;
};

export declare const LegacySequencerConfig:
  damlTypes.Serializable<LegacySequencerConfig> & {
  }
;


export declare type SequencerConfig = {
  migrationId: damlTypes.Int;
  sequencerId: string;
  url: string;
  availableAfter: damlTypes.Optional<damlTypes.Time>;
};

export declare const SequencerConfig:
  damlTypes.Serializable<SequencerConfig> & {
  }
;


export declare type SynchronizerState =
  | 'DS_Bootstrapping'
  | 'DS_Operational'
  | 'DS_Decomissioned'
  | 'ExtSynchronizerState'
;

export declare const SynchronizerState:
  damlTypes.Serializable<SynchronizerState> & {
  }
& { readonly keys: SynchronizerState[] } & { readonly [e in SynchronizerState]: e }
;


export declare type SynchronizerConfig = {
  state: SynchronizerState;
  cometBftGenesisJson: string;
  acsCommitmentReconciliationInterval: damlTypes.Optional<damlTypes.Int>;
};

export declare const SynchronizerConfig:
  damlTypes.Serializable<SynchronizerConfig> & {
  }
;


export declare type DsoDecentralizedSynchronizerConfig = {
  synchronizers: damlTypes.Map<string, SynchronizerConfig>;
  lastSynchronizerId: string;
  activeSynchronizerId: string;
};

export declare const DsoDecentralizedSynchronizerConfig:
  damlTypes.Serializable<DsoDecentralizedSynchronizerConfig> & {
  }
;

