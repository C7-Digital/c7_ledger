// Generated from Splice/SvOnboarding.daml
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/no-use-before-define */
import * as jtv from '@mojotech/json-type-validation';
import * as damlTypes from '@daml/types';

import * as pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69 from '@c7-digital/splice-codegen/ghc-stdlib-DA-Internal-Template-1.0.0';

export declare type SvOnboardingConfirmed_Expire = {
};

export declare const SvOnboardingConfirmed_Expire:
  damlTypes.Serializable<SvOnboardingConfirmed_Expire> & {
  }
;


export declare type SvOnboardingConfirmed = {
  svParty: damlTypes.Party;
  svName: string;
  svRewardWeight: damlTypes.Int;
  svParticipantId: string;
  reason: string;
  dso: damlTypes.Party;
  expiresAt: damlTypes.Time;
};

export declare interface SvOnboardingConfirmedInterface {
  Archive: damlTypes.Choice<SvOnboardingConfirmed, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<SvOnboardingConfirmed, undefined>>;
  SvOnboardingConfirmed_Expire: damlTypes.Choice<SvOnboardingConfirmed, SvOnboardingConfirmed_Expire, SvOnboardingConfirmed_ExpireResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<SvOnboardingConfirmed, undefined>>;
}
export declare const SvOnboardingConfirmed:
  damlTypes.Template<SvOnboardingConfirmed, undefined, '#splice-dso-governance:Splice.SvOnboarding:SvOnboardingConfirmed'> &
  damlTypes.ToInterface<SvOnboardingConfirmed, never> &
  SvOnboardingConfirmedInterface;

export declare namespace SvOnboardingConfirmed {
}



export declare type SvOnboardingRequest_Expire = {
};

export declare const SvOnboardingRequest_Expire:
  damlTypes.Serializable<SvOnboardingRequest_Expire> & {
  }
;


export declare type SvOnboardingRequest = {
  candidateName: string;
  candidateParty: damlTypes.Party;
  candidateParticipantId: string;
  token: string;
  sponsor: damlTypes.Party;
  dso: damlTypes.Party;
  expiresAt: damlTypes.Time;
};

export declare interface SvOnboardingRequestInterface {
  SvOnboardingRequest_Expire: damlTypes.Choice<SvOnboardingRequest, SvOnboardingRequest_Expire, SvOnboardingRequest_ExpireResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<SvOnboardingRequest, undefined>>;
  Archive: damlTypes.Choice<SvOnboardingRequest, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<SvOnboardingRequest, undefined>>;
}
export declare const SvOnboardingRequest:
  damlTypes.Template<SvOnboardingRequest, undefined, '#splice-dso-governance:Splice.SvOnboarding:SvOnboardingRequest'> &
  damlTypes.ToInterface<SvOnboardingRequest, never> &
  SvOnboardingRequestInterface;

export declare namespace SvOnboardingRequest {
}



export declare type SvOnboardingConfirmed_ExpireResult =
  | 'SvOnboardingConfirmed_ExpireResult'
;

export declare const SvOnboardingConfirmed_ExpireResult:
  damlTypes.Serializable<SvOnboardingConfirmed_ExpireResult> & {
  }
& { readonly keys: SvOnboardingConfirmed_ExpireResult[] } & { readonly [e in SvOnboardingConfirmed_ExpireResult]: e }
;


export declare type SvOnboardingRequest_ExpireResult =
  | 'SvOnboardingRequest_ExpireResult'
;

export declare const SvOnboardingRequest_ExpireResult:
  damlTypes.Serializable<SvOnboardingRequest_ExpireResult> & {
  }
& { readonly keys: SvOnboardingRequest_ExpireResult[] } & { readonly [e in SvOnboardingRequest_ExpireResult]: e }
;

