// Generated from Splice/DsoBootstrap.daml
/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/no-use-before-define */
import * as jtv from '@mojotech/json-type-validation';
import * as damlTypes from '@daml/types';

import * as pkg53468a38bce11b51cd2ed10b9c09301c0b73570b50896d5649c4629de15815a3 from '@c7-digital/splice-codegen/splice-amulet-name-service-0.1.16';
import * as pkg67fac2f853bce8dbf0b9817bb5ba7c59f10e8120b7c808696f7010e5f0c8a791 from '@c7-digital/splice-codegen/splice-amulet-0.1.15';
import * as pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69 from '@c7-digital/splice-codegen/ghc-stdlib-DA-Internal-Template-1.0.0';
import * as pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946 from '@c7-digital/splice-codegen/daml-stdlib-DA-Time-Types-1.0.0';

import * as Splice_DSO_DecentralizedSynchronizer from '../../Splice/DSO/DecentralizedSynchronizer/module';
import * as Splice_DsoRules from '../../Splice/DsoRules/module';

export declare type DsoBootstrap_Bootstrap = {
};

export declare const DsoBootstrap_Bootstrap:
  damlTypes.Serializable<DsoBootstrap_Bootstrap> & {
  }
;


export declare type DsoBootstrap = {
  dso: damlTypes.Party;
  sv1Party: damlTypes.Party;
  sv1Name: string;
  sv1RewardWeight: damlTypes.Int;
  sv1ParticipantId: string;
  sv1SynchronizerNodes: damlTypes.Map<string, Splice_DSO_DecentralizedSynchronizer.SynchronizerNodeConfig>;
  round0Duration: pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946.DA.Time.Types.RelTime;
  amuletConfig: pkg67fac2f853bce8dbf0b9817bb5ba7c59f10e8120b7c808696f7010e5f0c8a791.Splice.AmuletConfig.AmuletConfig<pkg67fac2f853bce8dbf0b9817bb5ba7c59f10e8120b7c808696f7010e5f0c8a791.Splice.AmuletConfig.USD>;
  amuletPrice: damlTypes.Numeric;
  ansRulesConfig: pkg53468a38bce11b51cd2ed10b9c09301c0b73570b50896d5649c4629de15815a3.Splice.Ans.AnsRulesConfig;
  config: Splice_DsoRules.DsoRulesConfig;
  initialTrafficState: damlTypes.Map<string, Splice_DsoRules.TrafficState>;
  isDevNet: boolean;
  initialRound: damlTypes.Optional<damlTypes.Int>;
};

export declare interface DsoBootstrapInterface {
  Archive: damlTypes.Choice<DsoBootstrap, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoBootstrap, undefined>>;
  DsoBootstrap_Bootstrap: damlTypes.Choice<DsoBootstrap, DsoBootstrap_Bootstrap, DsoBootstrap_BootstrapResult, undefined> & damlTypes.ChoiceFrom<damlTypes.Template<DsoBootstrap, undefined>>;
}
export declare const DsoBootstrap:
  damlTypes.Template<DsoBootstrap, undefined, '#splice-dso-governance:Splice.DsoBootstrap:DsoBootstrap'> &
  damlTypes.ToInterface<DsoBootstrap, never> &
  DsoBootstrapInterface;

export declare namespace DsoBootstrap {
}



export declare type DsoBootstrap_BootstrapResult =
  | 'DsoBootstrap_BootstrapResult'
;

export declare const DsoBootstrap_BootstrapResult:
  damlTypes.Serializable<DsoBootstrap_BootstrapResult> & {
  }
& { readonly keys: DsoBootstrap_BootstrapResult[] } & { readonly [e in DsoBootstrap_BootstrapResult]: e }
;

