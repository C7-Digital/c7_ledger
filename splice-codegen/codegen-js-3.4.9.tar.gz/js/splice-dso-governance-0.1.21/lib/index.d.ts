import * as Splice from './Splice';
export { Splice } ;
export declare const packageId = '2d306cfe8cdb3daf2d21f84dfecc3e2f26a41504e58fe25cb7fe5cc65683d11f';
