import * as Splice from './Splice';
export { Splice } ;
export declare const packageId = '53468a38bce11b51cd2ed10b9c09301c0b73570b50896d5649c4629de15815a3';
