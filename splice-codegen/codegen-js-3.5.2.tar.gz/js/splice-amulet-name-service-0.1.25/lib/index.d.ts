import * as Splice from './Splice';

export { Splice };

export declare const packageId = 'ed30b35402e14b31f351c525261315b6ee26d6c236a3d3b82899b3b600561b9c';
