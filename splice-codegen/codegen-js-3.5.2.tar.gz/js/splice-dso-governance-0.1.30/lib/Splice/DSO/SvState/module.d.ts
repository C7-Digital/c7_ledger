// Generated from ../../../Splice/DSO/SvState/module.daml

/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/no-use-before-define */
import * as jtv from '@mojotech/json-type-validation';
import * as damlTypes from '@daml/types';

import * as pkg17b6f7c18efec9022dde39a19039783c68490a722e8a5088b22ee034678171a2 from '@c7-digital/splice-codegen/splice-amulet-0.1.24';
import * as pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69 from '@c7-digital/splice-codegen/ghc-stdlib-DA-Internal-Template-1.0.0';

import * as Splice_DSO_DecentralizedSynchronizer from '../../../Splice/DSO/DecentralizedSynchronizer/module';

export declare type ForSv = {
  dso: damlTypes.Party,
  svName: string,
}

export declare const ForSv:
  damlTypes.Serializable<ForSv>

export declare type ForSvNode = {
  dso: damlTypes.Party,
  sv: damlTypes.Party,
  svName: string,
}

export declare const ForSvNode:
  damlTypes.Serializable<ForSvNode>

export declare type NodeState = {
  synchronizerNodes: damlTypes.Map<string, Splice_DSO_DecentralizedSynchronizer.SynchronizerNodeConfig>,
}

export declare const NodeState:
  damlTypes.Serializable<NodeState>

export declare type RewardState = {
  numRoundsMissed: damlTypes.Int,
  numRoundsCollected: damlTypes.Int,
  lastRoundCollected: pkg17b6f7c18efec9022dde39a19039783c68490a722e8a5088b22ee034678171a2.Splice.Types.Round,
  numCouponsIssued: damlTypes.Int,
}

export declare const RewardState:
  damlTypes.Serializable<RewardState>

export declare type SvNodeState = {
  dso: damlTypes.Party,
  sv: damlTypes.Party,
  svName: string,
  state: NodeState,
}

export declare interface SvNodeStateInterface {
  Archive: 
    damlTypes.Choice<SvNodeState, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> &
    damlTypes.ChoiceFrom<damlTypes.Template<SvNodeState, undefined>>;
}
export declare const SvNodeState:
  damlTypes.Template<SvNodeState, undefined, '#splice-dso-governance:Splice.DSO.SvState:SvNodeState'> &
  damlTypes.ToInterface<SvNodeState, never> &
  SvNodeStateInterface

export declare type SvRewardState = {
  dso: damlTypes.Party,
  svName: string,
  state: RewardState,
}

export declare interface SvRewardStateInterface {
  Archive: 
    damlTypes.Choice<SvRewardState, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> &
    damlTypes.ChoiceFrom<damlTypes.Template<SvRewardState, undefined>>;
}
export declare const SvRewardState:
  damlTypes.Template<SvRewardState, undefined, '#splice-dso-governance:Splice.DSO.SvState:SvRewardState'> &
  damlTypes.ToInterface<SvRewardState, never> &
  SvRewardStateInterface

export declare type SvStatus = {
  createdAt: damlTypes.Time,
  cometBftHeight: damlTypes.Int,
  mediatorSynchronizerTime: damlTypes.Time,
  participantSynchronizerTime: damlTypes.Time,
  latestOpenRound: pkg17b6f7c18efec9022dde39a19039783c68490a722e8a5088b22ee034678171a2.Splice.Types.Round,
}

export declare const SvStatus:
  damlTypes.Serializable<SvStatus>

export declare type SvStatusReport = {
  dso: damlTypes.Party,
  sv: damlTypes.Party,
  svName: string,
  number: damlTypes.Int,
  status: damlTypes.Optional<SvStatus>,
}

export declare interface SvStatusReportInterface {
  Archive: 
    damlTypes.Choice<SvStatusReport, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> &
    damlTypes.ChoiceFrom<damlTypes.Template<SvStatusReport, undefined>>;
}
export declare const SvStatusReport:
  damlTypes.Template<SvStatusReport, undefined, '#splice-dso-governance:Splice.DSO.SvState:SvStatusReport'> &
  damlTypes.ToInterface<SvStatusReport, never> &
  SvStatusReportInterface
