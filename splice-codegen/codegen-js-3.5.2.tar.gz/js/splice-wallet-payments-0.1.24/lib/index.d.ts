import * as Splice from './Splice';

export { Splice };

export declare const packageId = '6335771518a70ee8aba04270e0fab09755f26f8ac9856813629be33f291fe3cb';
