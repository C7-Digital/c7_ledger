// Generated from ../../Splice/AmuletAllocationV2/module.daml

/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/no-use-before-define */
import * as jtv from '@mojotech/json-type-validation';
import * as damlTypes from '@daml/types';

import * as pkg051a3b0563a6fa4df4cb34448081e48b061e555aa1a265abf6ae8f3f4cafe439 from '@c7-digital/splice-codegen/splice-api-token-allocation-v2-1.0.0';
import * as pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69 from '@c7-digital/splice-codegen/ghc-stdlib-DA-Internal-Template-1.0.0';

import * as Splice_Amulet from '../../Splice/Amulet/module';

export declare type AmuletAllocationV2 = {
  lockedAmulet: damlTypes.Optional<damlTypes.ContractId<Splice_Amulet.LockedAmulet>>,
  settlement: pkg051a3b0563a6fa4df4cb34448081e48b061e555aa1a265abf6ae8f3f4cafe439.Splice.Api.Token.AllocationV2.SettlementInfo,
  allocation: pkg051a3b0563a6fa4df4cb34448081e48b061e555aa1a265abf6ae8f3f4cafe439.Splice.Api.Token.AllocationV2.AllocationSpecification,
  expiresAt: damlTypes.Time,
  numIterations: damlTypes.Int,
  createdAt: damlTypes.Time,
}

export declare interface AmuletAllocationV2Interface {
  Archive: 
    damlTypes.Choice<AmuletAllocationV2, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> &
    damlTypes.ChoiceFrom<damlTypes.Template<AmuletAllocationV2, undefined>>;
}
export declare const AmuletAllocationV2:
  damlTypes.Template<AmuletAllocationV2, undefined, '#splice-amulet:Splice.AmuletAllocationV2:AmuletAllocationV2'> &
  damlTypes.ToInterface<AmuletAllocationV2, pkg051a3b0563a6fa4df4cb34448081e48b061e555aa1a265abf6ae8f3f4cafe439.Splice.Api.Token.AllocationV2.Allocation> &
  AmuletAllocationV2Interface
