// Generated from ../../../Splice/Amulet/RewardAccountingV2/module.daml

/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/no-use-before-define */
import * as jtv from '@mojotech/json-type-validation';
import * as damlTypes from '@daml/types';

import * as pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69 from '@c7-digital/splice-codegen/ghc-stdlib-DA-Internal-Template-1.0.0';
import * as pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946 from '@c7-digital/splice-codegen/daml-stdlib-DA-Time-Types-1.0.0';
import * as pkgc3bb0c5d04799b3f11bad7c3c102963e115cf53da3e4afcbcfd9f06ebd82b4ff from '@c7-digital/splice-codegen/daml-stdlib-DA-Set-Types-1.0.0';

import * as Splice_Amulet_CryptoHash from '../../../Splice/Amulet/CryptoHash/module';
import * as Splice_Types from '../../../Splice/Types/module';

export declare type Batch =
  | { tag: 'BatchOfBatches'; value: Splice_Amulet_CryptoHash.Hash[] }
  | { tag: 'BatchOfMintingAllowances'; value: MintingAllowance[] }


export declare const Batch:
  damlTypes.Serializable<Batch>

export declare type CalculateRewardsV2 = {
  dso: damlTypes.Party,
  round: Splice_Types.Round,
  roundClosedAt: damlTypes.Time,
  rewardCouponTimeToLive: pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946.DA.Time.Types.RelTime,
  dryRun: boolean,
}

export declare interface CalculateRewardsV2Interface {
  Archive: 
    damlTypes.Choice<CalculateRewardsV2, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> &
    damlTypes.ChoiceFrom<damlTypes.Template<CalculateRewardsV2, undefined>>;
}
export declare const CalculateRewardsV2:
  damlTypes.Template<CalculateRewardsV2, undefined, '#splice-amulet:Splice.Amulet.RewardAccountingV2:CalculateRewardsV2'> &
  damlTypes.ToInterface<CalculateRewardsV2, never> &
  CalculateRewardsV2Interface

export declare type MintingAllowance = {
  provider: damlTypes.Party,
  amount: damlTypes.Numeric,
}

export declare const MintingAllowance:
  damlTypes.Serializable<MintingAllowance>

export declare type ProcessRewardsV2 = {
  dso: damlTypes.Party,
  round: Splice_Types.Round,
  roundClosedAt: damlTypes.Time,
  dryRun: boolean,
  rewardCouponTimeToLive: pkgb70db8369e1c461d5c70f1c86f526a29e9776c655e6ffc2560f95b05ccb8b946.DA.Time.Types.RelTime,
  batchHash: Splice_Amulet_CryptoHash.Hash,
}

export declare interface ProcessRewardsV2Interface {
  Archive: 
    damlTypes.Choice<ProcessRewardsV2, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> &
    damlTypes.ChoiceFrom<damlTypes.Template<ProcessRewardsV2, undefined>>;
  ProcessRewardsV2_ProcessBatch: 
    damlTypes.Choice<ProcessRewardsV2, ProcessRewardsV2_ProcessBatch, ProcessRewardsV2_ProcessBatchResult, undefined> &
    damlTypes.ChoiceFrom<damlTypes.Template<ProcessRewardsV2, undefined>>;
}
export declare const ProcessRewardsV2:
  damlTypes.Template<ProcessRewardsV2, undefined, '#splice-amulet:Splice.Amulet.RewardAccountingV2:ProcessRewardsV2'> &
  damlTypes.ToInterface<ProcessRewardsV2, never> &
  ProcessRewardsV2Interface

export declare type ProcessRewardsV2_ProcessBatch = {
  batch: Batch,
  providersWithWrongVettingState: pkgc3bb0c5d04799b3f11bad7c3c102963e115cf53da3e4afcbcfd9f06ebd82b4ff.DA.Set.Types.Set<damlTypes.Party>,
}

export declare const ProcessRewardsV2_ProcessBatch:
  damlTypes.Serializable<ProcessRewardsV2_ProcessBatch>

export declare type ProcessRewardsV2_ProcessBatchResult = {
}

export declare const ProcessRewardsV2_ProcessBatchResult:
  damlTypes.Serializable<ProcessRewardsV2_ProcessBatchResult>
