// Generated from ../../../Splice/Amulet/CryptoHash/module.daml

/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/no-use-before-define */
import * as jtv from '@mojotech/json-type-validation';
import * as damlTypes from '@daml/types';

export declare type Hash = {
  value: string,
}

export declare const Hash:
  damlTypes.Serializable<Hash>
