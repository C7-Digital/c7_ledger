import * as Splice from './Splice';

export { Splice };

export declare const packageId = '17b6f7c18efec9022dde39a19039783c68490a722e8a5088b22ee034678171a2';
