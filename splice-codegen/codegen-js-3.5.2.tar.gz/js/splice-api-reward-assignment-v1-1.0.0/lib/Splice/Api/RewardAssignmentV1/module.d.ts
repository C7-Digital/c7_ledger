// Generated from ../../../Splice/Api/RewardAssignmentV1/module.daml

/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-namespace */
/* eslint-disable @typescript-eslint/no-use-before-define */
import * as jtv from '@mojotech/json-type-validation';
import * as damlTypes from '@daml/types';

import * as pkg4ded6b668cb3b64f7a88a30874cd41c75829f5e064b3fbbadf41ec7e8363354f from '@c7-digital/splice-codegen/splice-api-token-metadata-v1-1.0.0';
import * as pkg5aee9b21b8e9a4c4975b5f4c4198e6e6e8469df49e2010820e792f393db870f4 from '@c7-digital/splice-codegen/daml-prim-DA-Types-1.0.0';
import * as pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69 from '@c7-digital/splice-codegen/ghc-stdlib-DA-Internal-Template-1.0.0';

export declare type RewardCoupon = damlTypes.Interface<'#splice-api-reward-assignment-v1:Splice.Api.RewardAssignmentV1:RewardCoupon'> & RewardCouponView
export declare interface RewardCouponInterface {
  Archive:
    damlTypes.Choice<RewardCoupon, pkg9e70a8b3510d617f8a136213f33d6a903a10ca0eeec76bb06ba55d1ed9680f69.DA.Internal.Template.Archive, {}, undefined> &
    damlTypes.ChoiceFrom<damlTypes.InterfaceCompanion<RewardCoupon, undefined>>;
  RewardCoupon_AssignBeneficiaries:
    damlTypes.Choice<RewardCoupon, RewardCoupon_AssignBeneficiaries, RewardCoupon_AssignBeneficiariesResult, undefined> &
    damlTypes.ChoiceFrom<damlTypes.InterfaceCompanion<RewardCoupon, undefined>>;
}
export declare const RewardCoupon:
  damlTypes.InterfaceCompanion<RewardCoupon, undefined, '#splice-api-reward-assignment-v1:Splice.Api.RewardAssignmentV1:RewardCoupon'> &
  damlTypes.FromTemplate<RewardCoupon, unknown> &
  RewardCouponInterface

export declare type RewardBeneficiary = {
  beneficiary: damlTypes.Party,
  percentage: damlTypes.Numeric,
}

export declare const RewardBeneficiary:
  damlTypes.Serializable<RewardBeneficiary>

export declare type RewardCouponView = {
  dso: damlTypes.Party,
  provider: damlTypes.Party,
  beneficiary: damlTypes.Optional<damlTypes.Party>,
  amount: damlTypes.Numeric,
  expiresAt: damlTypes.Time,
  maxNumNewBeneficiaries: damlTypes.Int,
  meta: pkg4ded6b668cb3b64f7a88a30874cd41c75829f5e064b3fbbadf41ec7e8363354f.Splice.Api.Token.MetadataV1.Metadata,
}

export declare const RewardCouponView:
  damlTypes.Serializable<RewardCouponView>

export declare type RewardCoupon_AssignBeneficiaries = {
  additionalCoupons: damlTypes.ContractId<RewardCoupon>[],
  newBeneficiaries: RewardBeneficiary[],
  extraArgs: pkg4ded6b668cb3b64f7a88a30874cd41c75829f5e064b3fbbadf41ec7e8363354f.Splice.Api.Token.MetadataV1.ExtraArgs,
}

export declare const RewardCoupon_AssignBeneficiaries:
  damlTypes.Serializable<RewardCoupon_AssignBeneficiaries>

export declare type RewardCoupon_AssignBeneficiariesResult = {
  newBeneficiariesCouponCids: pkg5aee9b21b8e9a4c4975b5f4c4198e6e6e8469df49e2010820e792f393db870f4.DA.Types.Tuple2<damlTypes.Party, damlTypes.ContractId<RewardCoupon>[]>[],
}

export declare const RewardCoupon_AssignBeneficiariesResult:
  damlTypes.Serializable<RewardCoupon_AssignBeneficiariesResult>
